import { type User, type InsertUser, type GameState, type InsertGameState, type Mission, type InsertMission } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getGameState(userId: string): Promise<GameState | undefined>;
  createGameState(gameState: InsertGameState): Promise<GameState>;
  updateGameState(userId: string, gameState: Partial<GameState>): Promise<GameState>;
  
  getMissions(): Promise<Mission[]>;
  getMission(id: string): Promise<Mission | undefined>;
  createMission(mission: InsertMission): Promise<Mission>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private gameStates: Map<string, GameState>;
  private missions: Map<string, Mission>;

  constructor() {
    this.users = new Map();
    this.gameStates = new Map();
    this.missions = new Map();
    
    // Initialize with some default missions
    this.initializeMissions();
  }

  private initializeMissions() {
    const defaultMissions: InsertMission[] = [
      {
        title: "CORPORATE BREACH",
        description: "Infiltrate TechCorp's email system and extract CEO communications. Client suspects insider trading.",
        difficulty: "MEDIUM",
        reward: 3500,
        estimatedTime: 45,
        requiredSkills: ["emailSpoofing", "passwordCracking"],
        riskFactor: 45,
        available: true
      },
      {
        title: "GPS MANIPULATION",
        description: "Spoof delivery truck GPS to redirect packages. Anonymous client, crypto payment only.",
        difficulty: "LOW",
        reward: 1200,
        estimatedTime: 20,
        requiredSkills: ["gpsSpoofing", "networkIntrusion"],
        riskFactor: 25,
        available: true
      },
      {
        title: "GOVERNMENT DATABASE",
        description: "Extract classified documents from defense contractor. HIGH RISK - AI monitoring active.",
        difficulty: "HIGH",
        reward: 12000,
        estimatedTime: 120,
        requiredSkills: ["advancedHacking", "stealthMode"],
        riskFactor: 85,
        available: true
      }
    ];

    defaultMissions.forEach(mission => {
      const id = randomUUID();
      const fullMission: Mission = {
        ...mission,
        id,
        createdAt: new Date()
      };
      this.missions.set(id, fullMission);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    
    // Create default game state for new user
    await this.createGameState({ userId: id });
    
    return user;
  }

  async getGameState(userId: string): Promise<GameState | undefined> {
    return Array.from(this.gameStates.values()).find(
      (state) => state.userId === userId,
    );
  }

  async createGameState(gameState: InsertGameState): Promise<GameState> {
    const id = randomUUID();
    const now = new Date();
    const fullGameState: GameState = {
      id,
      ...gameState,
      credits: gameState.credits || 1247,
      riskLevel: gameState.riskLevel || "LOW",
      guildRank: gameState.guildRank || "INITIATE",
      reputation: gameState.reputation || 0,
      jobsCompleted: gameState.jobsCompleted || 0,
      successRate: gameState.successRate || 100,
      skills: gameState.skills || {
        passwordCracking: { level: 1, xp: 0, maxXp: 200 },
        networkIntrusion: { level: 1, xp: 0, maxXp: 200 },
        socialEngineering: { level: 1, xp: 0, maxXp: 200 },
        virusDevelopment: { level: 0, xp: 0, maxXp: 300, locked: true }
      },
      hardware: gameState.hardware || {
        quantumProcessor: false,
        stealthNetworkCard: true,
        neuralInterface: false
      },
      software: gameState.software || {
        ghostProxy: false,
        aiPatternDisruptor: false,
        rootAccessToolkit: false
      },
      activeMission: null,
      completedMissions: [],
      lastLogin: now,
      createdAt: now,
      updatedAt: now
    };
    
    this.gameStates.set(id, fullGameState);
    return fullGameState;
  }

  async updateGameState(userId: string, updates: Partial<GameState>): Promise<GameState> {
    const existingState = await this.getGameState(userId);
    if (!existingState) {
      throw new Error("Game state not found");
    }
    
    const updatedState: GameState = {
      ...existingState,
      ...updates,
      updatedAt: new Date()
    };
    
    this.gameStates.set(existingState.id, updatedState);
    return updatedState;
  }

  async getMissions(): Promise<Mission[]> {
    return Array.from(this.missions.values()).filter(m => m.available);
  }

  async getMission(id: string): Promise<Mission | undefined> {
    return this.missions.get(id);
  }

  async createMission(mission: InsertMission): Promise<Mission> {
    const id = randomUUID();
    const fullMission: Mission = {
      ...mission,
      id,
      createdAt: new Date()
    };
    this.missions.set(id, fullMission);
    return fullMission;
  }
}

export const storage = new MemStorage();
