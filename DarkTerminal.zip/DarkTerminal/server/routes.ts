import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertGameStateSchema, insertMissionSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Game state routes
  app.get("/api/game-state/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const gameState = await storage.getGameState(userId);
      
      if (!gameState) {
        return res.status(404).json({ message: "Game state not found" });
      }
      
      res.json(gameState);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch game state" });
    }
  });

  app.post("/api/game-state", async (req, res) => {
    try {
      const gameStateData = insertGameStateSchema.parse(req.body);
      const gameState = await storage.createGameState(gameStateData);
      res.json(gameState);
    } catch (error) {
      res.status(400).json({ message: "Invalid game state data" });
    }
  });

  app.patch("/api/game-state/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const updates = req.body;
      const gameState = await storage.updateGameState(userId, updates);
      res.json(gameState);
    } catch (error) {
      res.status(400).json({ message: "Failed to update game state" });
    }
  });

  // Mission routes
  app.get("/api/missions", async (req, res) => {
    try {
      const missions = await storage.getMissions();
      res.json(missions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch missions" });
    }
  });

  app.get("/api/missions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const mission = await storage.getMission(id);
      
      if (!mission) {
        return res.status(404).json({ message: "Mission not found" });
      }
      
      res.json(mission);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch mission" });
    }
  });

  app.post("/api/missions", async (req, res) => {
    try {
      const missionData = insertMissionSchema.parse(req.body);
      const mission = await storage.createMission(missionData);
      res.json(mission);
    } catch (error) {
      res.status(400).json({ message: "Invalid mission data" });
    }
  });

  // Command execution endpoint
  app.post("/api/execute-command", async (req, res) => {
    try {
      const { command, userId } = req.body;
      
      // Simple command processing logic
      let response = "";
      let updateGameState = false;
      let stateUpdates = {};
      
      switch (command.toLowerCase().split(' ')[0]) {
        case 'whoami':
          response = "anonymous_user_7331";
          break;
        case 'ls':
          response = `total 48
drwxr-xr-x  5 guest guild   4096 Oct 28 15:42 .
drwxr-xr-x  3 root  root    4096 Oct 15 10:30 ..
-rwx------  1 guest guild   1024 Oct 28 15:40 .blacknet_config
-rwxr-xr-x  1 guest guild   2048 Oct 28 15:35 mission_briefing.txt
-rwxr-xr-x  1 guest guild   8192 Oct 27 22:15 proxy_tools.bin
-rwx------  1 guest guild    512 Oct 28 14:20 secure_vault.enc
drwxr-xr-x  2 guest guild   4096 Oct 28 15:00 downloads
drwxr-xr-x  2 guest guild   4096 Oct 28 14:55 exploits`;
          break;
        case 'scan':
          response = "Scanning network... Found 3 vulnerable targets.";
          updateGameState = true;
          stateUpdates = { riskLevel: "MEDIUM" };
          break;
        case 'hack':
          response = "Initiating hack sequence... Authentication bypass successful.";
          updateGameState = true;
          stateUpdates = { 
            riskLevel: "HIGH",
            credits: 1247 + 500,
            skills: {
              passwordCracking: { level: 2, xp: 150, maxXp: 400 }
            }
          };
          break;
        case 'help':
          response = `Available commands:
- whoami: Display current user
- ls: List files in current directory  
- scan: Scan for network vulnerabilities
- hack [target]: Attempt to hack target system
- stealth: Enable stealth mode
- proxy: Route through proxy servers
- upload [file]: Upload virus to target
- clear: Clear terminal output`;
          break;
        case 'clear':
          response = "CLEAR_TERMINAL";
          break;
        default:
          response = `bash: ${command}: command not found`;
      }
      
      if (updateGameState && userId) {
        await storage.updateGameState(userId, stateUpdates);
      }
      
      res.json({ response, updateGameState, stateUpdates });
    } catch (error) {
      res.status(500).json({ message: "Command execution failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
