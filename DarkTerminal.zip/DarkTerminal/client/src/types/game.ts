export interface Skill {
  level: number;
  xp: number;
  maxXp: number;
  locked?: boolean;
}

export interface Skills {
  hacking: number;
  stealth: number;
  social: number;
  hardware: number;
}

export interface Hardware {
  processor: string;
  ram: string;
  network: string;
  storage: string;
}

export interface Software {
  os: string;
  proxy: string;
  encryption: string;
  firewall: string;
}

export interface GameStateType {
  id: string;
  userId?: string | null;
  credits: number;
  riskLevel: string;
  guildRank: string;
  reputation: number;
  jobsCompleted: number;
  successRate: number;
  skills: Skills;
  hardware: Hardware;
  software: Software;
  activeMission: any;
  createdAt: Date;
  updatedAt: Date;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  difficulty: "LOW" | "MEDIUM" | "HIGH";
  reward: number;
  estimatedTime: number;
  requiredSkills: string[];
  riskFactor: number;
  available: boolean;
  createdAt: Date;
}

export interface TerminalLine {
  id: string;
  text: string;
  type: 'input' | 'output' | 'error' | 'success';
  timestamp: Date;
}
