import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface TutorialModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface TutorialStep {
  title: string;
  content: string;
  highlight?: string;
}

const tutorialSteps: TutorialStep[] = [
  {
    title: "WELCOME TO BLACKNET",
    content: `You're a middle school kid who just discovered blacknet.exe on your busted laptop. 
    
This mysterious file opens up a fake OS interface that connects you to an underground hacker guild.

Your mission: Complete illegal jobs, upgrade your equipment, and avoid getting caught by government AI hunters.`,
    highlight: "WARNING: This is a simulation. Stay in character!"
  },
  {
    title: "THE TERMINAL",
    content: `The TERMINAL tab is your command center. Type commands to:
    
• scan - Find vulnerable targets
• hack [target] - Breach systems for money
• steal [data_type] - Extract valuable data
• stealth - Reduce your risk level
• proxy - Hide your location
• help - See all available commands

Advanced commands include decrypt, spoof, darknet, and more!`,
    highlight: "Try 'steal credit_cards' for big money but high risk"
  },
  {
    title: "DESKTOP & FILES",
    content: `The DESKTOP tab contains your hacking tools:
    
• Drag virus files to the upload zone
• Deploy malware on target systems
• Monitor system resources and stealth mode
• Manage your digital arsenal

Use these tools carefully - some operations are irreversible.`,
    highlight: "Virus deployment increases detection risk"
  },
  {
    title: "MISSIONS & CONTRACTS",
    content: `The MISSIONS tab shows available jobs from shadowy contacts:
    
• Corporate data breaches
• GPS manipulation contracts
• Government database infiltration
• Password cracking puzzles

Complete missions to earn credits and guild reputation.`,
    highlight: "Higher difficulty = Higher reward = Higher risk"
  },
  {
    title: "UPGRADES & SKILLS",
    content: `Use the UPGRADES tab to improve your setup:
    
HARDWARE:
• Quantum processors for faster cracking
• Stealth network cards for reduced detection
• Neural interfaces for instant commands

SOFTWARE:
• Ghost proxies for anonymity
• AI pattern disruptors to confuse hunters
• Root access toolkits (extreme risk)`,
    highlight: "Some upgrades require higher guild rank"
  },
  {
    title: "NETWORK TOPOLOGY",
    content: `The NETWORK tab shows your connection routes:
    
• Monitor proxy server chains
• Track AI hunter positions
• View compromised systems
• Plan attack vectors

Stay ahead of the hunters - they're always watching.`,
    highlight: "AI hunters get closer with each risky operation"
  },
  {
    title: "SURVIVAL TIPS",
    content: `Remember these rules to survive:
    
• Keep your RISK LEVEL low when possible
• Use proxy servers to hide your location  
• Complete jobs quickly before detection
• Upgrade your stealth capabilities
• Watch for AI hunter alerts

Get caught too many times and you'll be soft-banned from the network.`,
    highlight: "The guild protects its own - but only if you're useful"
  }
];

export default function TutorialModal({ isOpen, onClose }: TutorialModalProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [showTypewriter, setShowTypewriter] = useState(true);

  useEffect(() => {
    if (isOpen) {
      setShowTypewriter(true);
      const timer = setTimeout(() => setShowTypewriter(false), 100);
      return () => clearTimeout(timer);
    }
  }, [currentStep, isOpen]);

  const nextStep = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const completeTutorial = () => {
    localStorage.setItem('blacknet-tutorial-completed', 'true');
    onClose();
  };

  const step = tutorialSteps[currentStep];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-black border-terminal-green text-terminal-green font-mono max-w-2xl" data-testid="tutorial-modal">
        {/* CRT Effect */}
        <div className="absolute inset-0 bg-repeat pointer-events-none opacity-20" 
             style={{ 
               backgroundImage: `repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0, 255, 0, 0.03) 2px, rgba(0, 255, 0, 0.03) 4px)`
             }}>
        </div>
        
        <DialogHeader className="relative z-10">
          <DialogTitle className="text-terminal-bright terminal-glow text-xl" data-testid="tutorial-title">
            {step.title}
          </DialogTitle>
          <DialogDescription className="text-xs text-terminal-dim" data-testid="tutorial-progress">
            BRIEFING {currentStep + 1} OF {tutorialSteps.length}
          </DialogDescription>
        </DialogHeader>
        
        <div className="relative z-10 space-y-4" data-testid="tutorial-content">
          <div className="border border-terminal-green p-4 bg-opacity-5 bg-terminal-green">
            <div className={`text-sm leading-relaxed ${showTypewriter ? 'cursor' : ''}`} data-testid="tutorial-text">
              {step.content.split('\n').map((line, index) => (
                <div key={index} className="mb-2">
                  {line}
                </div>
              ))}
            </div>
            
            {step.highlight && (
              <div className="mt-4 p-3 border border-terminal-warning bg-opacity-10 bg-terminal-warning">
                <div className="text-terminal-warning text-sm" data-testid="tutorial-highlight">
                  ⚠️ {step.highlight}
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-between items-center">
            <Button 
              variant="outline" 
              size="sm"
              onClick={prevStep}
              disabled={currentStep === 0}
              className="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-black disabled:opacity-30"
              data-testid="tutorial-prev"
            >
              <ChevronLeft className="w-4 h-4 mr-1" />
              PREVIOUS
            </Button>

            <div className="flex space-x-2">
              {tutorialSteps.map((_, index) => (
                <div 
                  key={index}
                  className={`w-2 h-2 border ${
                    index === currentStep 
                      ? 'bg-terminal-bright border-terminal-bright' 
                      : index < currentStep 
                        ? 'bg-terminal-green border-terminal-green' 
                        : 'border-terminal-dim'
                  }`}
                  data-testid={`tutorial-indicator-${index}`}
                />
              ))}
            </div>

            {currentStep === tutorialSteps.length - 1 ? (
              <Button 
                variant="outline" 
                size="sm"
                onClick={completeTutorial}
                className="border-terminal-bright text-terminal-bright hover:bg-terminal-bright hover:text-black"
                data-testid="tutorial-complete"
              >
                BEGIN HACKING
              </Button>
            ) : (
              <Button 
                variant="outline" 
                size="sm"
                onClick={nextStep}
                className="border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-black"
                data-testid="tutorial-next"
              >
                NEXT
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}