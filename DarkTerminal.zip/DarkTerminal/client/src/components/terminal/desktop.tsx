import { useState } from 'react';
import { GameStateType } from '@/types/game';

interface DesktopProps {
  gameState: GameStateType;
}

interface FileItem {
  id: string;
  name: string;
  type: 'folder' | 'file' | 'encrypted' | 'virus' | 'data' | 'target';
  icon: string;
  color: string;
}

export default function Desktop({ gameState }: DesktopProps) {
  const [draggedFile, setDraggedFile] = useState<FileItem | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);

  const files: FileItem[] = [
    { id: '1', name: 'exploits', type: 'folder', icon: '📁', color: 'border-terminal-dim' },
    { id: '2', name: 'virus.exe', type: 'virus', icon: '📄', color: 'border-terminal-dim' },
    { id: '3', name: 'secure.enc', type: 'encrypted', icon: '🔒', color: 'border-terminal-dim' },
    { id: '4', name: 'trojan.bin', type: 'virus', icon: '⚠️', color: 'border-terminal-warning' },
    { id: '5', name: 'keylog.dat', type: 'data', icon: '📊', color: 'border-terminal-dim' },
    { id: '6', name: 'target.txt', type: 'target', icon: '🎯', color: 'border-terminal-bright' },
  ];

  const handleDragStart = (file: FileItem) => {
    setDraggedFile(file);
  };

  const handleDragEnd = () => {
    setDraggedFile(null);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    if (!draggedFile) return;

    setIsUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          return 100;
        }
        return prev + Math.random() * 20;
      });
    }, 200);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const systemStats = [
    { label: 'CPU USAGE', value: 34, color: 'progress-fill' },
    { label: 'MEMORY', value: 67, color: 'progress-fill' },
    { label: 'STEALTH MODE', value: 'ACTIVE', isText: true },
    { label: 'PROXY STATUS', value: '7 HOPS', isText: true },
    { label: 'LAST PING', value: '2 MIN AGO', isText: true, color: 'text-terminal-warning' },
  ];

  return (
    <div className="grid grid-cols-8 gap-4 h-full" data-testid="desktop-component">
      {/* File System */}
      <div className="col-span-6">
        <div className="border border-terminal-green p-4 h-full" data-testid="file-system">
          <h3 className="text-terminal-bright mb-4 border-b border-terminal-green pb-2" data-testid="file-system-title">
            FILE SYSTEM
          </h3>
          <div className="grid grid-cols-6 gap-4">
            {files.map((file) => (
              <div
                key={file.id}
                className={`file-item ${file.color} p-3 text-center cursor-pointer transition-all hover:border-terminal-bright`}
                draggable
                onDragStart={() => handleDragStart(file)}
                onDragEnd={handleDragEnd}
                data-testid={`file-item-${file.id}`}
              >
                <div className="text-2xl mb-2" data-testid={`file-icon-${file.id}`}>{file.icon}</div>
                <div className="text-xs" data-testid={`file-name-${file.id}`}>{file.name}</div>
              </div>
            ))}
          </div>
          
          {/* Drag & Drop Zone */}
          <div 
            className="mt-6 border-2 border-dashed border-terminal-dim p-8 text-center relative"
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            data-testid="drop-zone"
          >
            <div className="text-terminal-dim" data-testid="drop-zone-text">DROP FILES HERE TO UPLOAD</div>
            <div className="text-xs text-terminal-dim mt-2" data-testid="drop-zone-subtitle">
              Drag virus files to deploy on target systems
            </div>
            
            {isUploading && (
              <div className="mt-4" data-testid="upload-progress">
                <div className="text-xs text-terminal-bright mb-2">UPLOADING: {Math.round(uploadProgress)}%</div>
                <div className="w-full bg-black border border-terminal-green h-2">
                  <div 
                    className="progress-fill h-full transition-all duration-200" 
                    style={{ width: `${uploadProgress}%` }}
                  ></div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* System Status */}
      <div className="col-span-2">
        <div className="border border-terminal-green p-4 h-full" data-testid="system-status">
          <h3 className="text-terminal-bright mb-4 border-b border-terminal-green pb-2" data-testid="system-status-title">
            SYSTEM
          </h3>
          <div className="space-y-4 text-xs">
            {systemStats.map((stat, index) => (
              <div key={index} data-testid={`system-stat-${index}`}>
                <div className="text-terminal-dim" data-testid={`stat-label-${index}`}>{stat.label}</div>
                {stat.isText ? (
                  <div className={`mt-1 ${stat.color || 'text-terminal-bright'}`} data-testid={`stat-value-${index}`}>
                    {stat.value}
                  </div>
                ) : (
                  <div className="flex items-center mt-1">
                    <div className="flex-1 bg-black border border-terminal-green h-2 mr-2">
                      <div 
                        className="progress-fill h-full" 
                        style={{ width: `${stat.value}%` }}
                        data-testid={`progress-bar-${index}`}
                      ></div>
                    </div>
                    <span data-testid={`stat-percentage-${index}`}>{stat.value}%</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
