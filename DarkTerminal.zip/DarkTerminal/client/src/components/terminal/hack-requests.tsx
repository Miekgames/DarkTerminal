import { useState } from 'react';
import { useMobile } from '@/hooks/use-mobile';
import { useGameState } from '@/hooks/use-game-state';
import QuestTerminal from './quest-terminal';

interface HackJob {
  id: string;
  title: string;
  client: string;
  description: string;
  target: string;
  reward: number;
  difficulty: string;
  deadline: string;
  skillRequired: number;
  repRequired: number;
  commands: string[];
  expectedOutputs: string[];
  objective: string;
}

export default function HackRequests() {
  const isMobile = useMobile();
  const { gameState } = useGameState();
  const [activeJob, setActiveJob] = useState<HackJob | null>(null);
  const [selectedRequest, setSelectedRequest] = useState<string | null>(null);

  const hackJobs: HackJob[] = [
    {
      id: "job_001",
      client: "ScornedEx_92",
      title: "Revenge Hack",
      description: "My cheating ex posted my private photos. Make them regret it.",
      target: "Social media account",
      reward: 150,
      difficulty: "Easy",
      deadline: "2 hours",
      skillRequired: 25,
      repRequired: 5,
      objective: "Access target's social media and delete compromising photos",
      commands: ["scan", "hack socialmedia.com", "steal passwords"],
      expectedOutputs: [
        "Network scan complete. Social media servers found at socialmedia.com",
        "Initiating hack on socialmedia.com...\n[████████████████████████████████████████] 100%\nRoot access gained! User database accessed.",
        "Cracking password hashes...\n[████████████████████████████████████████] 100%\nTarget account credentials extracted\nPhotos deleted successfully\nCredits earned: $150"
      ]
    },
    {
      id: "job_002", 
      client: "BusinessRival",
      title: "Competitor Intelligence",
      description: "Need access to rival company's client database for market advantage.",
      target: "CRM system",
      reward: 800,
      difficulty: "Medium",
      deadline: "6 hours",
      skillRequired: 45,
      repRequired: 35,
      objective: "Infiltrate competitor's CRM and extract client database",
      commands: ["stealth", "proxy", "hack crm.rivalcorp.com", "steal corporate"],
      expectedOutputs: [
        "Stealth mode activated. Digital footprint minimized.\nAdvanced evasion protocols engaged.",
        "Proxy chain established. Traffic routing through 3 countries:\nGermany → Singapore → Brazil",
        "Initiating hack on crm.rivalcorp.com...\n[████████████████████████████████████████] 100%\nFirewall bypassed! CRM access gained.",
        "Extracting client database...\n[████████████████████████████████████████] 100%\nDownloaded: 2,847 client records, financial data\nCredits earned: $800"
      ]
    },
    {
      id: "job_003",
      client: "Anonymous_Whale",
      title: "Crypto Exchange Heist",
      description: "High-value target. Extract wallet keys from major exchange.",
      target: "Exchange database",
      reward: 8000,
      difficulty: "Expert",
      deadline: "12 hours", 
      skillRequired: 85,
      repRequired: 150,
      objective: "Breach crypto exchange security and extract private wallet keys",
      commands: ["proxy", "stealth", "spoof location", "hack cryptomax.org", "steal crypto", "launder"],
      expectedOutputs: [
        "Proxy chain established. Traffic routing through 7 countries:\nRussia → China → Iran → North Korea → Venezuela → Somalia → Anonymous",
        "Stealth mode activated. Military-grade evasion protocols engaged.\nZero-day exploits loaded.",
        "Location spoofed to: Pyongyang, North Korea\nDigital fingerprints altered. VPN cascade active.",
        "Initiating hack on cryptomax.org...\n[████████████████████████████████████████] 100%\nMulti-factor authentication bypassed! Exchange breached!",
        "Extracting wallet keys...\n[████████████████████████████████████████] 100%\nPrivate keys acquired: 47 wallets\nBitcoin: 127.3 BTC, Ethereum: 892.1 ETH\nEstimated value: $2.1M",
        "Laundering cryptocurrency through mixers...\n[████████████████████████████████████████] 100%\nFunds mixed through Tornado Cash\nClean funds received: $8000"
      ]
    },
    {
      id: "job_004",
      client: "InsiderTrader_X",
      title: "SEC Document Leak",
      description: "Need unreleased earnings reports before market open.",
      target: "Government database",
      reward: 2500,
      difficulty: "Hard",
      deadline: "4 hours",
      skillRequired: 70,
      repRequired: 80,
      objective: "Access SEC database and extract unreleased earnings reports",
      commands: ["proxy", "stealth", "spoof government", "hack sec.gov", "steal corporate"],
      expectedOutputs: [
        "Government proxy network activated.\nDiplomatic immunity protocols engaged.",
        "Federal-grade stealth mode activated.\nNSA detection countermeasures engaged.",
        "Government identity spoofed. FBI credentials verified.\nClassified access authorized.",
        "Initiating hack on sec.gov...\n[████████████████████████████████████████] 100%\nClassified systems breached! EDGAR database accessed.",
        "Extracting earnings reports...\n[████████████████████████████████████████] 100%\nQ4 reports downloaded for 12 Fortune 500 companies\nMarket advantage secured\nCredits earned: $2500"
      ]
    },
    {
      id: "job_005",
      client: "DisgruntledEmployee",
      title: "Corporate Sabotage",
      description: "Boss fired me unfairly. Destroy their project files.",
      target: "Internal servers",
      reward: 400,
      difficulty: "Medium",
      deadline: "8 hours",
      skillRequired: 50,
      repRequired: 25,
      objective: "Access corporate servers and delete specified project files",
      commands: ["stealth", "hack corporate.internal", "upload virus"],
      expectedOutputs: [
        "Stealth mode activated. Internal network scanning...\nEmployee credentials database located.",
        "Initiating hack on corporate.internal...\n[████████████████████████████████████████] 100%\nEmployee credentials compromised! Domain admin access gained.",
        "Uploading destructive payload...\n[████████████████████████████████████████] 100%\nLogic bomb deployed. Project files corrupted.\nBackup servers wiped. Revenge complete.\nCredits earned: $400"
      ]
    },
    {
      id: "job_006",
      client: "Identity_Thief",
      title: "Personal Data Harvest",
      description: "Mass extraction of SSNs and credit info from healthcare DB.",
      target: "Medical records",
      reward: 3200,
      difficulty: "Hard",
      deadline: "10 hours",
      skillRequired: 75,
      repRequired: 100,
      objective: "Breach healthcare database and extract personal identification data",
      commands: ["proxy", "stealth", "hack medicore.net", "steal identity", "launder"],
      expectedOutputs: [
        "Medical proxy chain established.\nHIPAA violation protocols engaged.",
        "Healthcare stealth mode activated.\nMedical database infiltration protocols loaded.",
        "Initiating hack on medicore.net...\n[████████████████████████████████████████] 100%\nPatient database compromised! HIPAA firewall bypassed.",
        "Extracting identity data...\n[████████████████████████████████████████] 100%\nSSNs and credit info harvested: 15,000 patient records\nData packaged for dark market sale.",
        "Laundering proceeds through dark markets...\n[████████████████████████████████████████] 100%\nIdentity broker payment processed\nClean payment received: $3200"
      ]
    },
    {
      id: "job_007",
      client: "State_Actor_007",
      title: "Infrastructure Attack",
      description: "Classified operation targeting power grid control systems.",
      target: "SCADA systems",
      reward: 15000,
      difficulty: "Master",
      deadline: "24 hours",
      skillRequired: 95,
      repRequired: 200,
      objective: "Compromise critical infrastructure SCADA control systems",
      commands: ["proxy", "stealth", "spoof government", "hack scada.powergrid.gov", "upload stuxnet"],
      expectedOutputs: [
        "Nation-state proxy network activated.\nDiplomatic immunity protocols engaged.\nSatellite uplink established.",
        "Military-grade stealth engaged.\nZero-day arsenal loaded. APT protocols active.",
        "Government identity spoofed. NSA credentials verified.\nCritical infrastructure clearance granted.",
        "Initiating hack on scada.powergrid.gov...\n[████████████████████████████████████████] 100%\nCritical infrastructure breached!\nSCADA control systems compromised.",
        "Deploying STUXNET variant...\n[████████████████████████████████████████] 100%\nPower grid control compromised\nCascading failure potential: ACTIVE\nMission complete. Payment authorized.\nCredits earned: $15000"
      ]
    },
    {
      id: "job_008",
      client: "CyberMerc_Alpha",
      title: "Ransomware Deployment",
      description: "Corporate client needs competitor's systems encrypted.",
      target: "Enterprise network",
      reward: 5500,
      difficulty: "Expert",
      deadline: "6 hours",
      skillRequired: 80,
      repRequired: 120,
      objective: "Deploy ransomware across competitor's enterprise network",
      commands: ["proxy", "stealth", "hack enterprise.competitor.com", "upload ransomware"],
      expectedOutputs: [
        "Corporate proxy network established.\nBusiness espionage mode activated.\nLegal deniability protocols engaged.",
        "Advanced stealth protocols active.\nAnti-forensics engaged. Attribution masking complete.",
        "Initiating hack on enterprise.competitor.com...\n[████████████████████████████████████████] 100%\nDomain controller compromised!\nActive Directory access gained.",
        "Deploying ransomware payload...\n[████████████████████████████████████████] 100%\nCrypto-locker spreading across network\n847 workstations encrypted\nRansom demand: $2M\nEstimated downtime: 3-6 weeks\nYour cut: $5500"
      ]
    }
  ];

  const canAcceptJob = (job: HackJob) => {
    const currentSkill = gameState?.skills?.hacking || 25;
    const currentRep = gameState?.reputation || 10;
    return currentSkill >= job.skillRequired && currentRep >= job.repRequired;
  };

  const acceptJob = (job: HackJob) => {
    if (canAcceptJob(job)) {
      setActiveJob(job);
    }
  };

  const completeJob = () => {
    setActiveJob(null);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'border-green-400 text-green-400';
      case 'Medium': return 'border-terminal-warning text-terminal-warning';
      case 'Hard': return 'border-orange-400 text-orange-400';
      case 'Expert': return 'border-terminal-error text-terminal-error';
      case 'Master': return 'border-purple-400 text-purple-400';
      default: return 'border-terminal-green text-terminal-green';
    }
  };

  return (
    <>
      <div className="space-y-6" data-testid="hack-requests-component">
        <div className="text-center border border-terminal-green p-4">
          <h2 className="text-terminal-bright text-xl mb-2" data-testid="hack-requests-title">
            UNDERGROUND HACK REQUESTS
          </h2>
          <p className="text-terminal-dim text-sm">
            Anonymous clients seeking hacking services. Accept jobs to earn credits and reputation.
          </p>
          <div className="text-xs text-terminal-warning mt-2">
            Your Stats: Hacking {gameState?.skills?.hacking || 25} | Reputation {gameState?.reputation || 10}
          </div>
        </div>

        <div className={`${isMobile ? 'space-y-4' : 'grid grid-cols-2 gap-4'}`}>
          {hackJobs.map((job) => (
            <div 
              key={job.id}
              className="border border-terminal-green p-4 hover:border-terminal-bright transition-colors"
              data-testid={`hack-job-${job.id}`}
            >
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="text-terminal-bright font-bold text-sm" data-testid={`job-title-${job.id}`}>
                    {job.title}
                  </h3>
                  <div className="text-xs text-terminal-dim">Client: {job.client}</div>
                </div>
                <span className={`text-xs border px-2 py-1 ${getDifficultyColor(job.difficulty)}`} data-testid={`job-difficulty-${job.id}`}>
                  {job.difficulty}
                </span>
              </div>
              
              <p className="text-sm text-terminal-dim mb-3" data-testid={`job-description-${job.id}`}>
                {job.description}
              </p>
              
              <div className="text-xs space-y-1 mb-3">
                <div><span className="text-terminal-warning">Target:</span> {job.target}</div>
                <div><span className="text-terminal-warning">Deadline:</span> {job.deadline}</div>
                <div><span className="text-terminal-warning">Objective:</span> {job.objective}</div>
              </div>
              
              <div className="flex justify-between items-center text-xs mb-3">
                <span className="text-terminal-bright font-bold" data-testid={`job-reward-${job.id}`}>
                  REWARD: ${job.reward.toLocaleString()}
                </span>
                <span className="text-terminal-dim">
                  Steps: {job.commands.length}
                </span>
              </div>
              
              <div className="text-xs text-terminal-dim mb-3">
                Required: Hack {job.skillRequired}+, Rep {job.repRequired}+
              </div>
              
              {canAcceptJob(job) ? (
                <button 
                  onClick={() => acceptJob(job)}
                  className="bg-terminal-green text-black px-3 py-1 text-xs font-bold hover:bg-terminal-bright transition-colors w-full"
                  data-testid={`accept-job-${job.id}`}
                >
                  ACCEPT JOB
                </button>
              ) : (
                <div className="text-terminal-error text-xs text-center py-1 border border-terminal-error">
                  INSUFFICIENT SKILLS/REPUTATION
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="border-t border-terminal-green pt-4">
          <div className="text-xs text-terminal-dim text-center">
            <p className="mb-2">⚠️ WARNING: All hack requests are simulated and fictional.</p>
            <p>Success rates vary based on your hacking skills and reputation level.</p>
            <p>Higher difficulty jobs offer better rewards but require advanced skills.</p>
          </div>
        </div>
      </div>

      {/* Job Terminal Modal */}
      {activeJob && (
        <QuestTerminal 
          quest={{
            id: activeJob.id,
            title: activeJob.title,
            description: `Client: ${activeJob.client}\n${activeJob.description}`,
            objective: activeJob.objective,
            commands: activeJob.commands,
            expectedOutputs: activeJob.expectedOutputs,
            reward: activeJob.reward,
            difficulty: activeJob.difficulty,
            skillRequired: activeJob.skillRequired,
            repRequired: activeJob.repRequired
          }}
          onComplete={completeJob}
          onClose={() => setActiveJob(null)}
        />
      )}
    </>
  );
}