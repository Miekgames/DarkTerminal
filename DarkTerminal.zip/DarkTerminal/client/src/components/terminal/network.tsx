import { GameStateType } from '@/types/game';

interface NetworkProps {
  gameState: GameStateType;
}

interface Server {
  id: string;
  name: string;
  location: string;
  uptime: string;
  bandwidth: string;
  security: string;
  dailyRate: number;
  status: 'ONLINE' | 'UNSTABLE' | 'OFFLINE';
}

interface Target {
  id: string;
  name: string;
  status: 'VULNERABLE' | 'PROTECTED' | 'FORTRESS';
}

export default function Network({ gameState }: NetworkProps) {
  const servers: Server[] = [
    {
      id: '1',
      name: 'DARKWEB-PROXY-07',
      location: 'Latvia',
      uptime: '99.7%',
      bandwidth: '100 Mbps',
      security: 'Military',
      dailyRate: 500,
      status: 'ONLINE'
    },
    {
      id: '2',
      name: 'GHOST-NODE-15',
      location: 'Russia',
      uptime: '97.2%',
      bandwidth: '250 Mbps',
      security: 'Corporate',
      dailyRate: 1200,
      status: 'ONLINE'
    },
    {
      id: '3',
      name: 'STEALTH-RELAY-03',
      location: 'Unknown',
      uptime: '45.1%',
      bandwidth: '50 Mbps',
      security: 'Government',
      dailyRate: 5000,
      status: 'UNSTABLE'
    }
  ];

  const targets: Target[] = [
    { id: '1', name: 'TechCorp Email Server', status: 'VULNERABLE' },
    { id: '2', name: 'CityBank Database', status: 'PROTECTED' },
    { id: '3', name: 'Gov Contractor Files', status: 'FORTRESS' }
  ];

  const getStatusColor = (status: Server['status']) => {
    switch (status) {
      case 'ONLINE': return 'text-green-400';
      case 'UNSTABLE': return 'text-terminal-warning';
      case 'OFFLINE': return 'text-terminal-error';
      default: return 'text-terminal-green';
    }
  };

  const getTargetStatusColor = (status: Target['status']) => {
    switch (status) {
      case 'VULNERABLE': return 'text-green-400';
      case 'PROTECTED': return 'text-terminal-warning';
      case 'FORTRESS': return 'text-terminal-error';
      default: return 'text-terminal-green';
    }
  };

  return (
    <div className="grid grid-cols-2 gap-6" data-testid="network-component">
      {/* Network Map */}
      <div>
        <h3 className="text-terminal-bright text-lg mb-4 border-b border-terminal-green pb-2" data-testid="network-topology-title">
          NETWORK TOPOLOGY
        </h3>
        <div className="border border-terminal-green p-4 h-96 relative" data-testid="network-map">
          <div className="relative h-full">
            {/* Network Nodes */}
            <div className="absolute top-8 left-8 w-3 h-3 bg-terminal-bright rounded-full animate-pulse" data-testid="node-you"></div>
            <div className="absolute top-8 left-12 text-xs" data-testid="label-you">YOU</div>
            
            <div className="absolute top-20 left-24 w-2 h-2 bg-terminal-green rounded-full" data-testid="node-proxy1"></div>
            <div className="absolute top-20 left-28 text-xs" data-testid="label-proxy1">PROXY-1</div>
            
            <div className="absolute top-32 left-40 w-2 h-2 bg-terminal-green rounded-full" data-testid="node-proxy2"></div>
            <div className="absolute top-32 left-44 text-xs" data-testid="label-proxy2">PROXY-2</div>
            
            <div className="absolute top-44 left-56 w-2 h-2 bg-terminal-warning rounded-full" data-testid="node-target"></div>
            <div className="absolute top-44 left-60 text-xs" data-testid="label-target">TARGET</div>
            
            <div className="absolute top-56 left-32 w-2 h-2 bg-terminal-error rounded-full animate-pulse" data-testid="node-hunter"></div>
            <div className="absolute top-56 left-36 text-xs" data-testid="label-hunter">HUNTER-AI</div>
            
            {/* Connection Lines */}
            <svg className="absolute inset-0 w-full h-full" data-testid="connection-lines">
              <line x1="40" y1="40" x2="60" y2="92" stroke="#00FF00" strokeWidth="1" strokeDasharray="2,2"/>
              <line x1="68" y1="92" x2="100" y2="140" stroke="#00FF00" strokeWidth="1" strokeDasharray="2,2"/>
              <line x1="108" y1="140" x2="140" y2="188" stroke="#00FF00" strokeWidth="1" strokeDasharray="2,2"/>
              <line x1="64" y1="228" x2="100" y2="140" stroke="#FF0000" strokeWidth="1" strokeDasharray="5,5" className="animate-pulse"/>
            </svg>
            
            <div className="absolute bottom-4 left-4 text-xs text-terminal-dim" data-testid="route-info">
              ROUTE: YOU → PROXY-1 → PROXY-2 → TARGET<br/>
              <span className="text-terminal-warning">AI HUNTER DETECTED - DISTANCE: 2 HOPS</span>
            </div>
          </div>
        </div>
      </div>

      {/* Server Access */}
      <div>
        <h3 className="text-terminal-bright text-lg mb-4 border-b border-terminal-green pb-2" data-testid="servers-title">
          COMPROMISED SERVERS
        </h3>
        <div className="space-y-3">
          {servers.map((server) => (
            <div key={server.id} className="border border-terminal-green p-3" data-testid={`server-${server.id}`}>
              <div className="flex justify-between items-center mb-2">
                <h4 className="text-terminal-bright font-bold" data-testid={`server-name-${server.id}`}>
                  {server.name}
                </h4>
                <span className={`text-xs ${getStatusColor(server.status)}`} data-testid={`server-status-${server.id}`}>
                  {server.status}
                </span>
              </div>
              <div className="text-xs text-terminal-dim mb-2" data-testid={`server-details-${server.id}`}>
                Location: {server.location} • Uptime: {server.uptime} • Bandwidth: {server.bandwidth}
              </div>
              <div className="flex justify-between text-xs">
                <span data-testid={`server-security-${server.id}`}>Security: {server.security}</span>
                <span className="text-terminal-bright" data-testid={`server-rate-${server.id}`}>
                  ${server.dailyRate}/day
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6" data-testid="available-targets">
          <h4 className="text-terminal-bright mb-3 border-b border-terminal-dim pb-1" data-testid="targets-title">
            AVAILABLE TARGETS
          </h4>
          <div className="space-y-2 text-xs">
            {targets.map((target) => (
              <div key={target.id} className="flex justify-between p-2 border border-terminal-dim" data-testid={`target-${target.id}`}>
                <span data-testid={`target-name-${target.id}`}>{target.name}</span>
                <span className={getTargetStatusColor(target.status)} data-testid={`target-status-${target.id}`}>
                  {target.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
