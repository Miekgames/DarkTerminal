import { useState, useRef, useEffect } from 'react';
import { GameStateType, TerminalLine } from '@/types/game';
import { useGameState } from '@/hooks/use-game-state';
import { useMobile } from '@/hooks/use-mobile';
import { v4 as uuidv4 } from 'uuid';

interface TerminalProps {
  gameState: GameStateType;
}

export default function Terminal({ gameState }: TerminalProps) {
  const [terminalLines, setTerminalLines] = useState<TerminalLine[]>([]);
  const [currentCommand, setCurrentCommand] = useState('');
  const terminalRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { executeCommand } = useGameState();
  const isMobile = useMobile();

  useEffect(() => {
    // Initialize with welcome message
    const welcomeLines: TerminalLine[] = [
      {
        id: uuidv4(),
        text: 'BLACKNET SECURE SHELL v2.4.7',
        type: 'success',
        timestamp: new Date()
      },
      {
        id: uuidv4(),
        text: 'Last login: Mon Oct 28 15:42:33 from 192.168.1.101',
        type: 'output',
        timestamp: new Date()
      },
      {
        id: uuidv4(),
        text: 'WARNING: Unauthorized access detected. Proceed with caution.',
        type: 'error',
        timestamp: new Date()
      },
      {
        id: uuidv4(),
        text: '',
        type: 'output',
        timestamp: new Date()
      },
      {
        id: uuidv4(),
        text: 'Type "help" to see available commands or click HELP button for full tutorial.',
        type: 'output',
        timestamp: new Date()
      }
    ];
    setTerminalLines(welcomeLines);
  }, []);

  useEffect(() => {
    // Auto-scroll to bottom
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [terminalLines]);

  const addLine = (text: string, type: TerminalLine['type']) => {
    const newLine: TerminalLine = {
      id: uuidv4(),
      text,
      type,
      timestamp: new Date()
    };
    setTerminalLines(prev => [...prev, newLine]);
  };

  const handleCommand = (command: string) => {
    // Add command to terminal
    addLine(`guest@blacknet:~$ ${command}`, 'input');

    if (command.toLowerCase() === 'clear') {
      setTerminalLines([]);
      return;
    }

    const result = executeCommand(command);
    
    if (result.response === 'CLEAR_TERMINAL') {
      setTerminalLines([]);
    } else {
      addLine(result.response, 'output');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && currentCommand.trim()) {
      handleCommand(currentCommand.trim());
      setCurrentCommand('');
    }
  };

  const getLineColor = (type: TerminalLine['type']) => {
    switch (type) {
      case 'input': return 'text-terminal-bright';
      case 'output': return 'text-terminal-green';
      case 'error': return 'text-terminal-error';
      case 'success': return 'text-terminal-bright terminal-glow';
      default: return 'text-terminal-green';
    }
  };

  return (
    <div className="h-full flex flex-col" data-testid="terminal-component">
      {/* System Info Banner */}
      <div className="mb-4 p-3 border border-terminal-green bg-opacity-10 bg-terminal-green" data-testid="system-banner">
        <div className="text-sm">
          <div className="terminal-glow" data-testid="system-title">BLACKNET SECURE SHELL v2.4.7</div>
          <div className="text-terminal-dim mt-1" data-testid="last-login">Last login: Mon Oct 28 15:42:33 from 192.168.1.101</div>
          <div className="text-terminal-warning mt-1" data-testid="warning-message">WARNING: Unauthorized access detected. Proceed with caution.</div>
        </div>
      </div>

      {/* Terminal Output */}
      <div 
        ref={terminalRef}
        className="flex-1 mb-4 overflow-auto" 
        data-testid="terminal-output"
      >
        <div className="space-y-1 text-sm">
          {terminalLines.map((line) => (
            <div 
              key={line.id} 
              className={getLineColor(line.type)}
              data-testid={`terminal-line-${line.type}`}
            >
              {line.text}
            </div>
          ))}
        </div>
      </div>

      {/* Command Input */}
      <div className="flex items-center border-t border-terminal-green pt-2" data-testid="command-input">
        <span className="text-terminal-bright mr-2" data-testid="command-prompt">guest@blacknet:~$</span>
        <input
          ref={inputRef}
          type="text"
          value={currentCommand}
          onChange={(e) => setCurrentCommand(e.target.value)}
          onKeyPress={handleKeyPress}
          className="flex-1 bg-transparent outline-none text-terminal-green"
          placeholder="Enter command... (try 'help')"
          data-testid="command-input-field"
        />
        <span className="cursor" data-testid="cursor"></span>
      </div>

      {/* Command Help */}
      <div className={`mt-2 text-xs text-terminal-dim ${isMobile ? 'text-center' : ''}`} data-testid="command-help">
        {isMobile ? 'Tip: Check BOOK tab for full command list | Try: practice, work, scan' : 'Tip: Check the HACKING BOOK tab for complete command reference with rewards and requirements'}
      </div>
    </div>
  );
}
