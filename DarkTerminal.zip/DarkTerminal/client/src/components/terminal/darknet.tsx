
import { GameStateType } from '@/types/game';
import { useGameState } from '@/hooks/use-game-state';
import { useState } from 'react';

interface DarknetProps {
  gameState: GameStateType;
}

interface DarknetItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'malware' | 'data' | 'tools' | 'services' | 'exploits';
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'EXTREME';
  vendor: string;
  rating: number;
  reviews: number;
  soldOut?: boolean;
  owned?: boolean;
}

interface Vendor {
  name: string;
  rating: number;
  joinDate: string;
  sales: number;
  verified: boolean;
}

export default function Darknet({ gameState }: DarknetProps) {
  const { updateGameState } = useGameState();
  const [activeCategory, setActiveCategory] = useState<string>('malware');
  const [selectedItem, setSelectedItem] = useState<DarknetItem | null>(null);

  const vendors: Vendor[] = [
    { name: 'ShadowCoder', rating: 4.8, joinDate: '2019', sales: 2847, verified: true },
    { name: 'DataVault99', rating: 4.6, joinDate: '2020', sales: 1923, verified: true },
    { name: 'ZeroDayKing', rating: 4.9, joinDate: '2018', sales: 3521, verified: true },
    { name: 'PhantomTools', rating: 4.2, joinDate: '2021', sales: 876, verified: false }
  ];

  const darknetItems: DarknetItem[] = [
    // Malware Arsenal
    {
      id: 'custom-rat',
      name: 'STEALTH RAT v4.2',
      description: 'Undetectable remote access trojan with keylogger, screen capture, and file exfiltration capabilities. AV bypass guaranteed.',
      price: 2500,
      category: 'malware',
      riskLevel: 'HIGH',
      vendor: 'ShadowCoder',
      rating: 4.8,
      reviews: 127
    },
    {
      id: 'crypto-miner',
      name: 'SILENT MINER',
      description: 'GPU cryptocurrency miner that operates below detection thresholds. Includes auto-update and stealth features.',
      price: 800,
      category: 'malware',
      riskLevel: 'MEDIUM',
      vendor: 'PhantomTools',
      rating: 4.1,
      reviews: 89
    },
    {
      id: 'botnet-kit',
      name: 'HYDRA BOTNET',
      description: 'Command & control infrastructure for up to 10,000 infected machines. DDoS, spam, and proxy capabilities included.',
      price: 15000,
      category: 'malware',
      riskLevel: 'EXTREME',
      vendor: 'ZeroDayKing',
      rating: 4.9,
      reviews: 34,
      soldOut: true
    },

    // Stolen Data
    {
      id: 'cc-dumps',
      name: 'FRESH CC DUMPS',
      description: '500 valid credit card numbers with CVV and billing info. US/EU cards only. 95% success rate guaranteed.',
      price: 5000,
      category: 'data',
      riskLevel: 'EXTREME',
      vendor: 'DataVault99',
      rating: 4.7,
      reviews: 203
    },
    {
      id: 'identity-pack',
      name: 'FULL IDENTITY PACKAGE',
      description: 'Complete identity theft kit: SSN, passport scan, drivers license, bank statements. Premium quality documents.',
      price: 3200,
      category: 'data',
      riskLevel: 'EXTREME',
      vendor: 'DataVault99',
      rating: 4.6,
      reviews: 156
    },
    {
      id: 'email-database',
      name: 'CORPORATE EMAIL DB',
      description: '2.3M corporate email addresses with passwords from recent breaches. Fortune 500 companies included.',
      price: 1200,
      category: 'data',
      riskLevel: 'HIGH',
      vendor: 'ShadowCoder',
      rating: 4.5,
      reviews: 78
    },

    // Hacking Tools
    {
      id: 'sql-injector',
      name: 'AUTO SQL INJECTOR',
      description: 'Automated SQL injection tool with 200+ payloads. Supports blind, time-based, and error-based attacks.',
      price: 450,
      category: 'tools',
      riskLevel: 'MEDIUM',
      vendor: 'PhantomTools',
      rating: 4.3,
      reviews: 234
    },
    {
      id: 'password-cracker',
      name: 'RAINBOW TABLES PRO',
      description: 'Pre-computed hash tables for instant password cracking. Supports MD5, SHA1, NTLM, and more.',
      price: 680,
      category: 'tools',
      riskLevel: 'LOW',
      vendor: 'ShadowCoder',
      rating: 4.6,
      reviews: 189
    },

    // Anonymous Services
    {
      id: 'vpn-premium',
      name: 'BULLETPROOF VPN',
      description: 'Military-grade VPN with no-logs policy. Servers in non-extradition countries. Perfect for darknet activities.',
      price: 200,
      category: 'services',
      riskLevel: 'LOW',
      vendor: 'PhantomTools',
      rating: 4.4,
      reviews: 567
    },
    {
      id: 'money-laundry',
      name: 'CRYPTO MIXING SERVICE',
      description: 'Clean your dirty crypto through multiple blockchain layers. 99.9% anonymity guaranteed.',
      price: 1500,
      category: 'services',
      riskLevel: 'HIGH',
      vendor: 'ZeroDayKing',
      rating: 4.8,
      reviews: 92
    },

    // Zero-Day Exploits
    {
      id: 'windows-zeroday',
      name: 'WINDOWS 11 0-DAY',
      description: 'Unpatched privilege escalation exploit for Windows 11. Works on all versions. Exclusive access for 30 days.',
      price: 50000,
      category: 'exploits',
      riskLevel: 'EXTREME',
      vendor: 'ZeroDayKing',
      rating: 5.0,
      reviews: 8,
      soldOut: true
    },
    {
      id: 'browser-exploit',
      name: 'CHROME RCE EXPLOIT',
      description: 'Remote code execution exploit for Chrome versions 98-104. Bypasses all security features.',
      price: 25000,
      category: 'exploits',
      riskLevel: 'EXTREME',
      vendor: 'ZeroDayKing',
      rating: 4.9,
      reviews: 12,
      soldOut: true
    }
  ];

  const categories = [
    { id: 'malware', name: 'MALWARE ARSENAL', icon: '🦠' },
    { id: 'data', name: 'STOLEN DATA', icon: '📊' },
    { id: 'tools', name: 'HACKING TOOLS', icon: '🔧' },
    { id: 'services', name: 'ANONYMOUS SERVICES', icon: '🌐' },
    { id: 'exploits', name: 'ZERO-DAY EXPLOITS', icon: '💥' }
  ];

  const handlePurchase = (item: DarknetItem) => {
    if (item.soldOut || item.owned || gameState.credits < item.price) return;

    const newCredits = gameState.credits - item.price;
    updateGameState({ credits: newCredits });
    
    // Mark item as owned (in real app, this would be persisted)
    item.owned = true;
    setSelectedItem(null);
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'LOW': return 'text-terminal-bright';
      case 'MEDIUM': return 'text-terminal-warning';
      case 'HIGH': return 'text-terminal-error';
      case 'EXTREME': return 'text-red-500 animate-pulse';
      default: return 'text-terminal-green';
    }
  };

  const getStars = (rating: number) => {
    return '★'.repeat(Math.floor(rating)) + '☆'.repeat(5 - Math.floor(rating));
  };

  const filteredItems = darknetItems.filter(item => item.category === activeCategory);

  return (
    <div className="darknet-container" data-testid="darknet-component">
      {/* Warning Header */}
      <div className="border border-red-500 bg-red-900 bg-opacity-20 p-4 mb-6 text-center">
        <div className="text-red-400 text-lg font-bold mb-2 animate-pulse">
          ⚠️ DARKNET MARKETPLACE - UNAUTHORIZED ACCESS ⚠️
        </div>
        <div className="text-red-300 text-sm">
          You are accessing illegal underground markets. All activities are monitored by law enforcement.
          This is a simulation - real darknet activities are illegal and dangerous.
        </div>
      </div>

      <div className="grid grid-cols-4 gap-6">
        {/* Categories Sidebar */}
        <div>
          <h3 className="text-terminal-bright text-lg mb-4 border-b border-terminal-green pb-2">
            CATEGORIES
          </h3>
          <div className="space-y-2">
            {categories.map((category) => (
              <button
                key={category.id}
                className={`w-full text-left p-3 border transition-all ${
                  activeCategory === category.id 
                    ? 'border-terminal-green bg-terminal-green bg-opacity-20' 
                    : 'border-terminal-dim hover:border-terminal-green'
                }`}
                onClick={() => setActiveCategory(category.id)}
                data-testid={`category-${category.id}`}
              >
                <div className="text-sm">
                  <span className="mr-2">{category.icon}</span>
                  {category.name}
                </div>
              </button>
            ))}
          </div>

          {/* Vendor Info */}
          <div className="mt-6">
            <h4 className="text-terminal-bright text-sm mb-3 border-b border-terminal-green pb-1">
              TOP VENDORS
            </h4>
            {vendors.slice(0, 3).map((vendor) => (
              <div key={vendor.name} className="mb-3 p-2 border border-terminal-dim">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-terminal-bright">
                    {vendor.verified && '✓ '}{vendor.name}
                  </span>
                  <span className="text-terminal-warning">{getStars(vendor.rating)}</span>
                </div>
                <div className="text-terminal-dim text-xs mt-1">
                  {vendor.sales} sales • Since {vendor.joinDate}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Items Grid */}
        <div className="col-span-3">
          <h3 className="text-terminal-bright text-lg mb-4 border-b border-terminal-green pb-2">
            {categories.find(c => c.id === activeCategory)?.name}
          </h3>
          
          <div className="grid grid-cols-2 gap-4">
            {filteredItems.map((item) => (
              <div 
                key={item.id} 
                className={`border p-4 cursor-pointer transition-all ${
                  item.soldOut 
                    ? 'border-red-500 opacity-50' 
                    : item.owned
                    ? 'border-terminal-dim opacity-75'
                    : 'border-terminal-green hover:bg-terminal-green hover:bg-opacity-10'
                }`}
                onClick={() => setSelectedItem(item)}
                data-testid={`item-${item.id}`}
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="text-terminal-bright font-bold text-sm">
                    {item.name}
                  </h4>
                  {item.soldOut && (
                    <span className="text-red-400 text-xs font-bold">SOLD OUT</span>
                  )}
                  {item.owned && (
                    <span className="text-terminal-dim text-xs">OWNED</span>
                  )}
                </div>
                
                <div className="text-xs text-terminal-dim mb-3 line-clamp-3">
                  {item.description}
                </div>
                
                <div className="flex justify-between items-center text-xs mb-2">
                  <span className="text-terminal-warning">
                    ${item.price.toLocaleString()}
                  </span>
                  <span className={`font-bold ${getRiskColor(item.riskLevel)}`}>
                    {item.riskLevel} RISK
                  </span>
                </div>
                
                <div className="flex justify-between items-center text-xs">
                  <span className="text-terminal-dim">
                    by {item.vendor}
                  </span>
                  <div className="flex items-center space-x-1">
                    <span className="text-terminal-warning">{getStars(item.rating)}</span>
                    <span className="text-terminal-dim">({item.reviews})</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Item Detail Modal */}
      {selectedItem && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50" data-testid="item-modal">
          <div className="bg-black border border-terminal-green p-6 max-w-2xl w-full mx-4">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-terminal-bright text-xl font-bold">
                {selectedItem.name}
              </h3>
              <button 
                className="text-terminal-dim hover:text-terminal-green"
                onClick={() => setSelectedItem(null)}
              >
                ✕
              </button>
            </div>
            
            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-terminal-warning text-lg">
                  ${selectedItem.price.toLocaleString()}
                </span>
                <span className={`font-bold ${getRiskColor(selectedItem.riskLevel)}`}>
                  {selectedItem.riskLevel} RISK
                </span>
              </div>
              
              <div className="text-sm text-terminal-dim mb-4">
                {selectedItem.description}
              </div>
              
              <div className="border border-terminal-dim p-3 mb-4">
                <div className="text-terminal-bright font-bold mb-2">Vendor Information</div>
                <div className="text-sm space-y-1">
                  <div>Name: {selectedItem.vendor}</div>
                  <div>Rating: {getStars(selectedItem.rating)} ({selectedItem.reviews} reviews)</div>
                  <div className="text-terminal-warning">
                    ⚠️ Purchase at your own risk - no refunds available
                  </div>
                </div>
              </div>
              
              {selectedItem.soldOut ? (
                <button className="w-full border border-red-500 text-red-500 py-2 px-4 cursor-not-allowed">
                  SOLD OUT
                </button>
              ) : selectedItem.owned ? (
                <button className="w-full border border-terminal-dim text-terminal-dim py-2 px-4 cursor-not-allowed">
                  ALREADY OWNED
                </button>
              ) : gameState.credits < selectedItem.price ? (
                <button className="w-full border border-terminal-dim text-terminal-dim py-2 px-4 cursor-not-allowed">
                  INSUFFICIENT FUNDS
                </button>
              ) : (
                <button 
                  className="w-full border border-terminal-green text-terminal-green hover:bg-terminal-green hover:text-black py-2 px-4 transition-all"
                  onClick={() => handlePurchase(selectedItem)}
                >
                  PURCHASE NOW
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Bottom Warning */}
      <div className="mt-8 border-t border-terminal-dim pt-4 text-center">
        <div className="text-terminal-dim text-xs">
          🚨 LEGAL DISCLAIMER: This is a fictional simulation. All items, vendors, and activities are completely fake.
          Real darknet marketplaces involve illegal activities that can result in serious legal consequences.
          This game does not promote or encourage illegal behavior. 🚨
        </div>
      </div>
    </div>
  );
}
