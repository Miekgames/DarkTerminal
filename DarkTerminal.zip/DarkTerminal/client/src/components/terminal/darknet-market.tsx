
import { GameStateType } from '@/types/game';
import { useGameState } from '@/hooks/use-game-state';
import { useState } from 'react';

interface DarknetMarketProps {
  gameState: GameStateType;
}

interface MarketItem {
  id: string;
  name: string;
  description: string;
  price: number;
  bitcoinPrice?: number;
  owned: boolean;
  locked?: boolean;
  category: 'exploits' | 'services' | 'data' | 'crypto';
  riskLevel: 'HIGH' | 'EXTREME' | 'LETHAL';
  sellerRating: number;
  sellerName: string;
}

interface Message {
  id: string;
  from: string;
  content: string;
  timestamp: string;
  category: 'job' | 'threat' | 'offer';
}

export default function DarknetMarket({ gameState }: DarknetMarketProps) {
  const { updateGameState } = useGameState();
  const [activeSection, setActiveSection] = useState<'market' | 'messages' | 'reputation'>('market');
  const [selectedCategory, setSelectedCategory] = useState<'exploits' | 'services' | 'data' | 'crypto'>('exploits');

  const exploitItems: MarketItem[] = [
    {
      id: 'zerodayExploit',
      name: 'WINDOWS 0-DAY EXPLOIT',
      description: 'Unreported vulnerability in Windows kernel. Bypasses all security. Government grade.',
      price: 250000,
      bitcoinPrice: 8.5,
      owned: false,
      locked: gameState.guildRank === 'NOVICE',
      category: 'exploits',
      riskLevel: 'LETHAL',
      sellerRating: 4.9,
      sellerName: 'Gh0stC0der'
    },
    {
      id: 'bankingTrojan',
      name: 'BANKING TROJAN KIT',
      description: 'Complete package for stealing financial credentials. Includes crypter and C&C panel.',
      price: 45000,
      bitcoinPrice: 1.5,
      owned: false,
      category: 'exploits',
      riskLevel: 'EXTREME',
      sellerRating: 4.7,
      sellerName: 'CyberViper'
    },
    {
      id: 'ransomwareBuilder',
      name: 'RANSOMWARE BUILDER v4.2',
      description: 'Military-grade encryption. Untraceable payment system. Automated victim communication.',
      price: 85000,
      bitcoinPrice: 2.8,
      owned: false,
      locked: gameState.reputation < 500,
      category: 'exploits',
      riskLevel: 'LETHAL',
      sellerRating: 4.8,
      sellerName: 'DarkPhoenix'
    }
  ];

  const serviceItems: MarketItem[] = [
    {
      id: 'hitmanService',
      name: 'PROFESSIONAL ELIMINATION',
      description: 'Discrete problem solving. International reach. No questions asked. 99.7% success rate.',
      price: 500000,
      bitcoinPrice: 16.7,
      owned: false,
      locked: gameState.reputation < 1000,
      category: 'services',
      riskLevel: 'LETHAL',
      sellerRating: 5.0,
      sellerName: 'TheSilencer'
    },
    {
      id: 'documentForger',
      name: 'IDENTITY FABRICATION',
      description: 'Complete new identity package. Passports, driver licenses, birth certificates. Government databases modified.',
      price: 75000,
      bitcoinPrice: 2.5,
      owned: false,
      category: 'services',
      riskLevel: 'EXTREME',
      sellerRating: 4.6,
      sellerName: 'DocMaster'
    },
    {
      id: 'moneyLaunderer',
      name: 'CRYPTOCURRENCY WASHING',
      description: 'Clean your dirty crypto through multiple mixer chains. Offshore shell companies included.',
      price: 25000,
      bitcoinPrice: 0.8,
      owned: false,
      category: 'services',
      riskLevel: 'HIGH',
      sellerRating: 4.9,
      sellerName: 'CleanSlate'
    }
  ];

  const dataItems: MarketItem[] = [
    {
      id: 'creditCardDump',
      name: 'PREMIUM CC DUMP (10K CARDS)',
      description: 'Fresh credit card data with CVV and billing info. High balance cards from wealthy targets.',
      price: 35000,
      bitcoinPrice: 1.2,
      owned: false,
      category: 'data',
      riskLevel: 'EXTREME',
      sellerRating: 4.5,
      sellerName: 'CardShark'
    },
    {
      id: 'corporateSecrets',
      name: 'FORTUNE 500 INSIDER DATA',
      description: 'Confidential merger plans, financial reports, executive communications. Market manipulation gold.',
      price: 150000,
      bitcoinPrice: 5.0,
      owned: false,
      locked: gameState.guildRank === 'NOVICE',
      category: 'data',
      riskLevel: 'LETHAL',
      sellerRating: 4.8,
      sellerName: 'InsiderTrade'
    },
    {
      id: 'govDatabase',
      name: 'CLASSIFIED GOVERNMENT FILES',
      description: 'Intelligence agency documents. Military secrets. Political blackmail material. Handle with care.',
      price: 1000000,
      bitcoinPrice: 33.3,
      owned: false,
      locked: gameState.reputation < 2000,
      category: 'data',
      riskLevel: 'LETHAL',
      sellerRating: 5.0,
      sellerName: 'StateSecret'
    }
  ];

  const cryptoItems: MarketItem[] = [
    {
      id: 'stolenBitcoin',
      name: 'CLEAN BITCOIN WALLET',
      description: 'Pre-laundered cryptocurrency from exchange hacks. Untraceable through multiple mixers.',
      price: 100000,
      bitcoinPrice: 3.3,
      owned: false,
      category: 'crypto',
      riskLevel: 'EXTREME',
      sellerRating: 4.7,
      sellerName: 'CryptoGhost'
    },
    {
      id: 'miningBotnet',
      name: 'CRYPTOCURRENCY MINING BOTNET',
      description: '50,000 infected machines mining for you. Generates $500/day in crypto. Remote management included.',
      price: 200000,
      bitcoinPrice: 6.7,
      owned: false,
      locked: gameState.guildRank === 'NOVICE',
      category: 'crypto',
      riskLevel: 'LETHAL',
      sellerRating: 4.9,
      sellerName: 'BotHerder'
    }
  ];

  const messages: Message[] = [
    {
      id: 'msg1',
      from: 'DarkPhoenix',
      content: 'Your ransomware deployment was noticed by feds. Lay low for 48hrs. Payment ready when you are.',
      timestamp: '2 min ago',
      category: 'threat'
    },
    {
      id: 'msg2',
      from: 'TheSilencer',
      content: 'New contract available. High-profile target. $2M payout. Interested?',
      timestamp: '15 min ago',
      category: 'job'
    },
    {
      id: 'msg3',
      from: 'CardShark',
      content: 'Fresh dump incoming tonight. Premium cards from Beverly Hills bank hack. Early access for VIP customers.',
      timestamp: '1 hr ago',
      category: 'offer'
    },
    {
      id: 'msg4',
      from: 'System_Alert',
      content: 'WARNING: Law enforcement activity increased 340% in your region. Consider relocating operations.',
      timestamp: '3 hrs ago',
      category: 'threat'
    }
  ];

  const getAllItems = () => {
    switch (selectedCategory) {
      case 'exploits': return exploitItems;
      case 'services': return serviceItems;
      case 'data': return dataItems;
      case 'crypto': return cryptoItems;
      default: return exploitItems;
    }
  };

  const handlePurchase = (item: MarketItem) => {
    if (item.owned || item.locked || gameState.credits < item.price) return;

    // Purchasing from darknet increases risk significantly
    const riskIncrease = item.riskLevel === 'LETHAL' ? 30 : item.riskLevel === 'EXTREME' ? 20 : 10;
    
    updateGameState({
      credits: gameState.credits - item.price,
      riskLevel: 'HIGH', // Darknet purchases always increase risk
      reputation: gameState.reputation + (item.riskLevel === 'LETHAL' ? 50 : 25)
    });
  };

  const getButtonText = (item: MarketItem) => {
    if (item.locked) return 'RESTRICTED';
    if (item.owned) return 'OWNED';
    return 'BUY NOW';
  };

  const getButtonStyle = (item: MarketItem) => {
    if (item.locked) return 'border-terminal-error text-terminal-error cursor-not-allowed';
    if (item.owned) return 'border-terminal-dim text-terminal-dim cursor-not-allowed';
    if (gameState.credits < item.price) return 'border-terminal-dim text-terminal-dim cursor-not-allowed';
    return 'border-red-500 hover:bg-red-500 hover:text-black transition-all text-red-400';
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'HIGH': return 'text-yellow-400';
      case 'EXTREME': return 'text-orange-400';
      case 'LETHAL': return 'text-red-400';
      default: return 'text-terminal-green';
    }
  };

  const getMessageStyle = (category: string) => {
    switch (category) {
      case 'threat': return 'border-red-500 bg-red-900 bg-opacity-20';
      case 'job': return 'border-yellow-500 bg-yellow-900 bg-opacity-20';
      case 'offer': return 'border-purple-500 bg-purple-900 bg-opacity-20';
      default: return 'border-terminal-green';
    }
  };

  return (
    <div className="text-red-300" data-testid="darknet-market">
      {/* Warning Banner */}
      <div className="border border-red-500 bg-red-900 bg-opacity-30 p-4 mb-6 text-center">
        <div className="text-red-400 font-bold text-lg mb-2">⚠️ DARKNET MARKETPLACE ⚠️</div>
        <div className="text-sm text-red-300">
          ILLEGAL ACTIVITIES - HIGH RISK - LAW ENFORCEMENT MONITORING
        </div>
        <div className="text-xs text-red-400 mt-1">
          All transactions are irreversible and carry severe legal consequences
        </div>
      </div>

      {/* Navigation */}
      <div className="flex border-b border-red-500 mb-6">
        {(['market', 'messages', 'reputation'] as const).map((section) => (
          <button
            key={section}
            className={`px-4 py-2 text-sm border-r border-red-500 hover:bg-red-900 hover:bg-opacity-30 transition-all ${
              activeSection === section ? 'bg-red-900 bg-opacity-50 text-red-300' : 'text-red-400'
            }`}
            onClick={() => setActiveSection(section)}
          >
            {section.toUpperCase()}
          </button>
        ))}
      </div>

      {activeSection === 'market' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Category Selection */}
          <div>
            <h3 className="text-red-300 text-lg mb-4 border-b border-red-500 pb-2">CATEGORIES</h3>
            <div className="space-y-2">
              {(['exploits', 'services', 'data', 'crypto'] as const).map((category) => (
                <button
                  key={category}
                  className={`block w-full text-left px-3 py-2 border transition-all ${
                    selectedCategory === category 
                      ? 'border-red-500 bg-red-900 bg-opacity-30 text-red-300' 
                      : 'border-red-600 text-red-400 hover:bg-red-900 hover:bg-opacity-20'
                  }`}
                  onClick={() => setSelectedCategory(category)}
                >
                  {category === 'exploits' && '🔪 EXPLOITS & MALWARE'}
                  {category === 'services' && '💀 BLACK MARKET SERVICES'}
                  {category === 'data' && '💳 STOLEN DATA'}
                  {category === 'crypto' && '₿ CRYPTOCURRENCY'}
                </button>
              ))}
            </div>
          </div>

          {/* Items List */}
          <div className="lg:col-span-3">
            <h3 className="text-red-300 text-lg mb-4 border-b border-red-500 pb-2">
              {selectedCategory.toUpperCase()} MARKETPLACE
            </h3>
            <div className="space-y-4">
              {getAllItems().map((item) => (
                <div 
                  key={item.id} 
                  className="border border-red-600 p-4 bg-black bg-opacity-50"
                >
                  <div className="flex justify-between items-start mb-3">
                    <h4 className="text-red-300 font-bold">{item.name}</h4>
                    <div className="text-right">
                      <div className={`text-xs ${getRiskColor(item.riskLevel)}`}>
                        RISK: {item.riskLevel}
                      </div>
                      <div className="text-xs text-red-400">
                        ★ {item.sellerRating}/5.0 ({item.sellerName})
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-xs text-red-400 mb-3 leading-relaxed">
                    {item.description}
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="text-red-300 font-bold">
                        ${item.price.toLocaleString()}
                      </div>
                      {item.bitcoinPrice && (
                        <div className="text-xs text-yellow-400">
                          ₿ {item.bitcoinPrice} BTC
                        </div>
                      )}
                      {item.locked && (
                        <div className="text-xs text-red-500 mt-1">
                          {gameState.guildRank === 'NOVICE' ? 'REPUTATION TOO LOW' : `REQUIRES ${item.locked ? 'HIGHER' : ''} GUILD RANK`}
                        </div>
                      )}
                    </div>
                    <button 
                      className={`border px-4 py-2 text-sm ${getButtonStyle(item)}`}
                      onClick={() => handlePurchase(item)}
                      disabled={item.owned || item.locked || gameState.credits < item.price}
                    >
                      {getButtonText(item)}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeSection === 'messages' && (
        <div>
          <h3 className="text-red-300 text-lg mb-4 border-b border-red-500 pb-2">
            ENCRYPTED COMMUNICATIONS
          </h3>
          <div className="space-y-3">
            {messages.map((message) => (
              <div 
                key={message.id}
                className={`border p-4 ${getMessageStyle(message.category)}`}
              >
                <div className="flex justify-between items-center mb-2">
                  <span className="font-bold text-red-300">{message.from}</span>
                  <span className="text-xs text-red-400">{message.timestamp}</span>
                </div>
                <div className="text-sm text-red-200">{message.content}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSection === 'reputation' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-red-300 text-lg mb-4 border-b border-red-500 pb-2">
              CRIMINAL REPUTATION
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Underground Rating:</span>
                <span className="text-red-300">★★★★☆ (4.2/5.0)</span>
              </div>
              <div className="flex justify-between">
                <span>Completed Contracts:</span>
                <span className="text-red-300">{gameState.jobsCompleted + 47}</span>
              </div>
              <div className="flex justify-between">
                <span>Law Enforcement Heat:</span>
                <span className="text-red-400">HIGH</span>
              </div>
              <div className="flex justify-between">
                <span>Trust Level:</span>
                <span className="text-red-300">VERIFIED CRIMINAL</span>
              </div>
              <div className="flex justify-between">
                <span>Darknet Reputation:</span>
                <span className="text-red-300">+{gameState.reputation + 1500}</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-red-300 text-lg mb-4 border-b border-red-500 pb-2">
              CRIMINAL CONTACTS
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>💀 TheSilencer:</span>
                <span className="text-red-400">ASSASSINATION</span>
              </div>
              <div className="flex justify-between">
                <span>🔪 DarkPhoenix:</span>
                <span className="text-red-400">RANSOMWARE</span>
              </div>
              <div className="flex justify-between">
                <span>💳 CardShark:</span>
                <span className="text-red-400">FINANCIAL FRAUD</span>
              </div>
              <div className="flex justify-between">
                <span>📄 DocMaster:</span>
                <span className="text-red-400">IDENTITY THEFT</span>
              </div>
              <div className="flex justify-between">
                <span>₿ CleanSlate:</span>
                <span className="text-red-400">MONEY LAUNDERING</span>
              </div>
              <div className="flex justify-between">
                <span>🕵️ StateSecret:</span>
                <span className="text-red-400">ESPIONAGE</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Warning */}
      <div className="mt-8 border-t border-red-500 pt-4 text-center">
        <div className="text-red-500 text-sm font-bold">
          ⚠️ FICTIONAL CONTENT WARNING ⚠️
        </div>
        <div className="text-xs text-red-400 mt-2">
          This darknet marketplace is completely fictional and for entertainment only. 
          All illegal activities, services, and products are fake. Real criminal activity is illegal and harmful.
          This game does not promote or encourage illegal behavior.
        </div>
      </div>
    </div>
  );
}
