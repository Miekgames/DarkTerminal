import { useMobile } from '@/hooks/use-mobile';

export default function HackingBook() {
  const isMobile = useMobile();

  const commands = [
    {
      category: "BEGINNER EARNING",
      commands: [
        { cmd: "practice", desc: "Practice on test servers", reward: "$20-50", risk: "None", skillReq: "None" },
        { cmd: "work", desc: "Legitimate programming jobs", reward: "$30-80", risk: "None", skillReq: "None" }
      ]
    },
    {
      category: "BASIC OPERATIONS", 
      commands: [
        { cmd: "whoami", desc: "Display current user info", reward: "None", risk: "None", skillReq: "None" },
        { cmd: "ls", desc: "List files and directories", reward: "None", risk: "None", skillReq: "None" },
        { cmd: "clear", desc: "Clear terminal output", reward: "None", risk: "None", skillReq: "None" },
        { cmd: "help", desc: "Show command reference", reward: "None", risk: "None", skillReq: "None" }
      ]
    },
    {
      category: "RECONNAISSANCE",
      commands: [
        { cmd: "scan", desc: "Scan network for vulnerabilities", reward: "Intel", risk: "Low", skillReq: "None" },
        { cmd: "trace", desc: "Check for surveillance", reward: "Security info", risk: "Medium", skillReq: "25+" },
        { cmd: "exploit", desc: "List available exploits", reward: "Tools", risk: "Low", skillReq: "None" }
      ]
    },
    {
      category: "OFFENSIVE OPERATIONS",
      commands: [
        { cmd: "hack [target]", desc: "Breach target system", reward: "$100-300", risk: "High", skillReq: "Skill based" },
        { cmd: "decrypt [file]", desc: "Crack encryption", reward: "$50-200", risk: "Medium", skillReq: "Skill based" },
        { cmd: "upload [malware]", desc: "Deploy malware", reward: "$200-500", risk: "High", skillReq: "40+" }
      ]
    },
    {
      category: "DATA THEFT",
      commands: [
        { cmd: "steal passwords", desc: "Steal password databases", reward: "$200", risk: "Medium", skillReq: "Hack: 30, Rep: 25" },
        { cmd: "steal identity", desc: "Harvest personal data", reward: "$400", risk: "Medium", skillReq: "Hack: 40, Rep: 30" },
        { cmd: "steal credit_cards", desc: "Breach payment processors", reward: "$800", risk: "High", skillReq: "Hack: 60, Rep: 80" },
        { cmd: "steal crypto", desc: "Mine cryptocurrency wallets", reward: "$1200", risk: "High", skillReq: "Hack: 70, Rep: 100" },
        { cmd: "steal corporate", desc: "Extract trade secrets", reward: "$2000", risk: "High", skillReq: "Hack: 80, Rep: 120" }
      ]
    },
    {
      category: "STEALTH & EVASION",
      commands: [
        { cmd: "stealth", desc: "Enable stealth mode", reward: "Protection", risk: "None", skillReq: "None" },
        { cmd: "proxy", desc: "Route through proxy chain", reward: "Anonymity", risk: "Low", skillReq: "None" },
        { cmd: "spoof [type]", desc: "Spoof identity/location", reward: "Disguise", risk: "Medium", skillReq: "30+" },
        { cmd: "launder", desc: "Launder stolen money", reward: "Clean cash", risk: "Low", skillReq: "Fee: 15-30%" }
      ]
    },
    {
      category: "ADVANCED OPERATIONS",
      commands: [
        { cmd: "darknet", desc: "Access dark web services", reward: "Black market", risk: "High", skillReq: "50+" },
        { cmd: "social", desc: "Social engineering tools", reward: "Profiles", risk: "Medium", skillReq: "40+" },
        { cmd: "ddos [target]", desc: "Distributed denial of service", reward: "$300-600", risk: "High", skillReq: "60+" },
        { cmd: "ransom [target]", desc: "Deploy ransomware", reward: "$1000-5000", risk: "Extreme", skillReq: "80+" }
      ]
    }
  ];

  return (
    <div className={`h-full bg-black text-terminal-green font-mono crt-scanlines ${isMobile ? 'text-xs p-2' : 'p-4'}`} data-testid="hacking-book">
      <div className="border border-terminal-green p-4 h-full overflow-auto">
        <div className="text-center mb-4">
          <div className="text-terminal-bright font-bold text-lg">THE HACKER'S MANUAL</div>
          <div className="text-terminal-dim text-sm">Complete Command Reference & Guide</div>
        </div>

        <div className="space-y-6">
          {commands.map((section, sectionIdx) => (
            <div key={sectionIdx} className="border border-terminal-dim p-3">
              <h3 className="text-terminal-bright font-bold mb-3 text-center">
                {section.category}
              </h3>
              
              <div className="space-y-2">
                {section.commands.map((command, cmdIdx) => (
                  <div key={cmdIdx} className={`grid ${isMobile ? 'grid-cols-1 gap-1' : 'grid-cols-6 gap-4'} border-b border-terminal-dim pb-2`}>
                    <div className={`text-terminal-bright font-bold ${isMobile ? 'text-center' : ''}`}>
                      {command.cmd}
                    </div>
                    <div className={`${isMobile ? 'text-center text-xs' : 'col-span-2'} text-terminal-green`}>
                      {command.desc}
                    </div>
                    <div className={`${isMobile ? 'text-center text-xs' : ''} text-terminal-warning`}>
                      {command.reward}
                    </div>
                    <div className={`${isMobile ? 'text-center text-xs' : ''} ${
                      command.risk === 'None' ? 'text-terminal-green' :
                      command.risk === 'Low' ? 'text-terminal-bright' :
                      command.risk === 'Medium' ? 'text-terminal-warning' :
                      'text-terminal-error'
                    }`}>
                      {command.risk}
                    </div>
                    <div className={`${isMobile ? 'text-center text-xs' : ''} text-terminal-dim`}>
                      {command.skillReq}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 p-3 border border-terminal-warning">
          <div className="text-terminal-warning font-bold text-center mb-2">⚠️ WARNING ⚠️</div>
          <div className="text-xs text-terminal-dim">
            All criminal activities are monitored by AI hunters. Higher risk operations have higher failure rates
            and reputation costs. Build your skills gradually to improve success rates.
          </div>
        </div>
      </div>
    </div>
  );
}