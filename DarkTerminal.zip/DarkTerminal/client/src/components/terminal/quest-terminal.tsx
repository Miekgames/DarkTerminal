import { useState, useRef, useEffect } from 'react';
import { useMobile } from '@/hooks/use-mobile';
import { useGameState } from '@/hooks/use-game-state';
import { v4 as uuidv4 } from 'uuid';

interface QuestTerminalProps {
  quest: {
    id: string;
    title: string;
    description: string;
    objective: string;
    commands: string[];
    expectedOutputs: string[];
    reward: number;
    difficulty: string;
  };
  onComplete: () => void;
  onClose: () => void;
}

interface QuestLine {
  id: string;
  text: string;
  type: 'input' | 'output' | 'error' | 'success' | 'objective';
  timestamp: Date;
}

export default function QuestTerminal({ quest, onComplete, onClose }: QuestTerminalProps) {
  const [questLines, setQuestLines] = useState<QuestLine[]>([]);
  const [currentCommand, setCurrentCommand] = useState('');
  const [completedSteps, setCompletedSteps] = useState<number>(0);
  const terminalRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { executeCommand, gameState, updateGameState } = useGameState();
  const isMobile = useMobile();

  useEffect(() => {
    // Initialize quest terminal
    const welcomeLines: QuestLine[] = [
      {
        id: uuidv4(),
        text: `QUEST TERMINAL ACTIVATED - ${quest.title}`,
        type: 'success',
        timestamp: new Date()
      },
      {
        id: uuidv4(),
        text: quest.description,
        type: 'output',
        timestamp: new Date()
      },
      {
        id: uuidv4(),
        text: '',
        type: 'output',
        timestamp: new Date()
      },
      {
        id: uuidv4(),
        text: `OBJECTIVE: ${quest.objective}`,
        type: 'objective',
        timestamp: new Date()
      },
      {
        id: uuidv4(),
        text: '',
        type: 'output',
        timestamp: new Date()
      },
      {
        id: uuidv4(),
        text: `REQUIRED COMMANDS (in order):`,
        type: 'output',
        timestamp: new Date()
      },
      ...quest.commands.map((cmd, idx) => ({
        id: uuidv4(),
        text: `${idx + 1}. ${cmd}`,
        type: 'output' as const,
        timestamp: new Date()
      })),
      {
        id: uuidv4(),
        text: '',
        type: 'output',
        timestamp: new Date()
      },
      {
        id: uuidv4(),
        text: 'Begin by typing the first command...',
        type: 'output',
        timestamp: new Date()
      }
    ];
    setQuestLines(welcomeLines);
  }, [quest]);

  useEffect(() => {
    // Auto-scroll to bottom
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [questLines]);

  useEffect(() => {
    // Focus input when component mounts
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  const addLine = (text: string, type: QuestLine['type']) => {
    const newLine: QuestLine = {
      id: uuidv4(),
      text,
      type,
      timestamp: new Date()
    };
    setQuestLines(prev => [...prev, newLine]);
  };

  const handleCommand = (command: string) => {
    // Add command to terminal
    addLine(`quest@terminal:~$ ${command}`, 'input');

    // Check if this is the expected command
    const expectedCommand = quest.commands[completedSteps];
    const normalizedCommand = command.toLowerCase().trim();
    const normalizedExpected = expectedCommand.toLowerCase().trim();

    if (normalizedCommand === normalizedExpected || 
        (normalizedExpected.includes('[') && normalizedCommand.startsWith(normalizedExpected.split('[')[0].trim()))) {
      
      // Execute the actual command
      const result = executeCommand(command);
      
      // Add the expected output or actual result
      const expectedOutput = quest.expectedOutputs[completedSteps];
      addLine(expectedOutput || result.response, 'success');

      // Update game state if needed
      if (result.updateGameState) {
        updateGameState(result.stateUpdates);
      }

      const newCompletedSteps = completedSteps + 1;
      setCompletedSteps(newCompletedSteps);

      // Check if quest is complete
      if (newCompletedSteps >= quest.commands.length) {
        setTimeout(() => {
          addLine('', 'output');
          addLine('QUEST COMPLETED SUCCESSFULLY!', 'success');
          addLine(`Reward: $${quest.reward} credits`, 'success');
          addLine('Experience gained: +10 Hacking, +5 Reputation', 'success');
          
          // Award quest completion
          const currentCredits = gameState?.credits || 0;
          updateGameState({
            credits: currentCredits + quest.reward,
            reputation: (gameState?.reputation || 0) + 5,
            skills: {
              hacking: Math.min(100, (gameState?.skills?.hacking || 25) + 10),
              stealth: gameState?.skills?.stealth || 15,
              social: gameState?.skills?.social || 20,
              hardware: gameState?.skills?.hardware || 10
            },
            jobsCompleted: (gameState?.jobsCompleted || 0) + 1
          });

          setTimeout(() => {
            onComplete();
          }, 2000);
        }, 1000);
      } else {
        setTimeout(() => {
          addLine('', 'output');
          addLine(`Step ${newCompletedSteps} complete. Continue with next command...`, 'output');
        }, 500);
      }
    } else {
      addLine(`ERROR: Expected command "${expectedCommand}"`, 'error');
      addLine('Try again with the correct command.', 'error');
    }

    setCurrentCommand('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && currentCommand.trim()) {
      handleCommand(currentCommand.trim());
    }
  };

  const getLineTypeColor = (type: QuestLine['type']) => {
    switch (type) {
      case 'input': return 'text-terminal-bright';
      case 'success': return 'text-terminal-green';
      case 'error': return 'text-terminal-error';
      case 'objective': return 'text-terminal-warning';
      default: return 'text-terminal-green';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50" data-testid="quest-terminal-modal">
      <div className={`bg-black border-2 border-terminal-green ${isMobile ? 'w-full h-full' : 'w-4/5 h-4/5'} flex flex-col`}>
        {/* Quest Header */}
        <div className="border-b border-terminal-green p-3 flex justify-between items-center">
          <div>
            <div className="text-terminal-bright font-bold">{quest.title}</div>
            <div className="text-xs text-terminal-dim">
              Progress: {completedSteps}/{quest.commands.length} | Difficulty: {quest.difficulty}
            </div>
          </div>
          <button 
            onClick={onClose}
            className="text-terminal-error hover:text-terminal-bright border border-terminal-error hover:border-terminal-bright px-2 py-1 text-xs"
          >
            ABORT
          </button>
        </div>

        {/* Terminal Output */}
        <div 
          ref={terminalRef}
          className={`flex-1 overflow-auto ${isMobile ? 'p-2' : 'p-4'} font-mono text-sm bg-black crt-scanlines`}
        >
          {questLines.map((line, index) => (
            <div key={line.id} className={`${getLineTypeColor(line.type)} mb-1`}>
              {line.text}
            </div>
          ))}
        </div>

        {/* Input Area */}
        <div className="border-t border-terminal-green p-3">
          <div className="flex items-center space-x-2">
            <span className="text-terminal-green">quest@terminal:~$</span>
            <input
              ref={inputRef}
              type="text"
              value={currentCommand}
              onChange={(e) => setCurrentCommand(e.target.value)}
              onKeyPress={handleKeyPress}
              className="flex-1 bg-transparent text-terminal-green outline-none font-mono"
              placeholder="Enter command..."
              data-testid="quest-command-input"
            />
            <span className="cursor animate-pulse">|</span>
          </div>
          
          <div className="text-xs text-terminal-dim mt-2">
            Next: {completedSteps < quest.commands.length ? quest.commands[completedSteps] : 'Quest Complete!'}
          </div>
        </div>
      </div>
    </div>
  );
}