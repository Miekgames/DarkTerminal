import { GameStateType } from '@/types/game';
import { useGameState } from '@/hooks/use-game-state';

interface UpgradesProps {
  gameState: GameStateType;
}

interface UpgradeItem {
  id: string;
  name: string;
  description: string;
  price: number;
  owned: boolean;
  locked?: boolean;
  category: 'hardware' | 'software';
}

export default function Upgrades({ gameState }: UpgradesProps) {
  const { updateGameState, addCredits } = useGameState();

  const hardwareUpgrades: UpgradeItem[] = [
    {
      id: 'quantumProcessor',
      name: 'QUANTUM PROCESSOR',
      description: 'Reduces cracking time by 40%. Unlocks advanced encryption tools.',
      price: 15000,
      owned: gameState.hardware.quantumProcessor,
      category: 'hardware'
    },
    {
      id: 'stealthNetworkCard',
      name: 'STEALTH NETWORK CARD',
      description: 'Reduces detection risk by 25%. Enables deep web access.',
      price: 8500,
      owned: gameState.hardware.stealthNetworkCard,
      category: 'hardware'
    },
    {
      id: 'neuralInterface',
      name: 'NEURAL INTERFACE',
      description: 'Direct brain-to-system connection. Instant command execution.',
      price: 50000,
      owned: gameState.hardware.neuralInterface,
      locked: gameState.guildRank !== 'MASTER',
      category: 'hardware'
    }
  ];

  const softwareUpgrades: UpgradeItem[] = [
    {
      id: 'ghostProxy',
      name: 'GHOST PROXY v3.1',
      description: 'Military-grade anonymization. Bounces through 15+ nodes.',
      price: 3200,
      owned: gameState.software.ghostProxy,
      category: 'software'
    },
    {
      id: 'aiPatternDisruptor',
      name: 'AI PATTERN DISRUPTOR',
      description: 'Confuses government AI tracking algorithms.',
      price: 7800,
      owned: gameState.software.aiPatternDisruptor,
      category: 'software'
    },
    {
      id: 'rootAccessToolkit',
      name: 'ROOT ACCESS TOOLKIT',
      description: 'Ultimate system control. WARNING: Extreme detection risk.',
      price: 0,
      owned: gameState.software.rootAccessToolkit,
      locked: gameState.guildRank !== 'ELITE',
      category: 'software'
    }
  ];

  const handlePurchase = (upgrade: UpgradeItem) => {
    if (upgrade.owned || upgrade.locked || gameState.credits < upgrade.price) return;

    const newCredits = gameState.credits - upgrade.price;
    const updatedHardware = upgrade.category === 'hardware' 
      ? { ...gameState.hardware, [upgrade.id]: true }
      : gameState.hardware;
    const updatedSoftware = upgrade.category === 'software'
      ? { ...gameState.software, [upgrade.id]: true }
      : gameState.software;

    updateGameState({
      credits: newCredits,
      hardware: updatedHardware,
      software: updatedSoftware
    });
  };

  const getButtonText = (upgrade: UpgradeItem) => {
    if (upgrade.locked) return upgrade.category === 'software' ? 'RESTRICTED' : 'LOCKED';
    if (upgrade.owned) return 'OWNED';
    return upgrade.category === 'hardware' ? 'PURCHASE' : 'DOWNLOAD';
  };

  const getButtonStyle = (upgrade: UpgradeItem) => {
    if (upgrade.locked) return 'border-terminal-error text-terminal-error cursor-not-allowed';
    if (upgrade.owned) return 'border-terminal-dim text-terminal-dim cursor-not-allowed';
    if (gameState.credits < upgrade.price) return 'border-terminal-dim text-terminal-dim cursor-not-allowed';
    return 'border-terminal-green hover:bg-terminal-green hover:text-black transition-all';
  };

  const skills = Object.entries(gameState.skills);

  return (
    <div className="grid grid-cols-3 gap-6" data-testid="upgrades-component">
      {/* Hardware */}
      <div>
        <h3 className="text-terminal-bright text-lg mb-4 border-b border-terminal-green pb-2" data-testid="hardware-title">
          HARDWARE
        </h3>
        <div className="space-y-4">
          {hardwareUpgrades.map((upgrade) => (
            <div 
              key={upgrade.id} 
              className={`border p-4 ${upgrade.owned ? 'border-terminal-dim opacity-75' : 'border-terminal-green'}`}
              data-testid={`hardware-${upgrade.id}`}
            >
              <h4 className="text-terminal-bright font-bold mb-2" data-testid={`hardware-name-${upgrade.id}`}>
                {upgrade.name}
              </h4>
              <div className="text-xs text-terminal-dim mb-3" data-testid={`hardware-description-${upgrade.id}`}>
                {upgrade.description}
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className={upgrade.locked ? "text-terminal-error" : "text-terminal-warning"} data-testid={`hardware-price-${upgrade.id}`}>
                  {upgrade.locked ? (upgrade.category === 'software' ? 'GUILD RANK 5+' : '$50,000') : `$${upgrade.price.toLocaleString()}`}
                </span>
                <button 
                  className={`border px-3 py-1 text-xs ${getButtonStyle(upgrade)}`}
                  onClick={() => handlePurchase(upgrade)}
                  disabled={upgrade.owned || upgrade.locked || gameState.credits < upgrade.price}
                  data-testid={`hardware-button-${upgrade.id}`}
                >
                  {getButtonText(upgrade)}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Software */}
      <div>
        <h3 className="text-terminal-bright text-lg mb-4 border-b border-terminal-green pb-2" data-testid="software-title">
          SOFTWARE
        </h3>
        <div className="space-y-4">
          {softwareUpgrades.map((upgrade) => (
            <div 
              key={upgrade.id} 
              className={`border p-4 ${upgrade.owned ? 'border-terminal-dim opacity-75' : upgrade.locked ? 'border-terminal-error' : 'border-terminal-green'}`}
              data-testid={`software-${upgrade.id}`}
            >
              <h4 className="text-terminal-bright font-bold mb-2" data-testid={`software-name-${upgrade.id}`}>
                {upgrade.name}
              </h4>
              <div className="text-xs text-terminal-dim mb-3" data-testid={`software-description-${upgrade.id}`}>
                {upgrade.description}
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className={upgrade.locked ? "text-terminal-error" : "text-terminal-warning"} data-testid={`software-price-${upgrade.id}`}>
                  {upgrade.locked ? 'GUILD RANK 5+' : `$${upgrade.price.toLocaleString()}`}
                </span>
                <button 
                  className={`border px-3 py-1 text-xs ${getButtonStyle(upgrade)}`}
                  onClick={() => handlePurchase(upgrade)}
                  disabled={upgrade.owned || upgrade.locked || gameState.credits < upgrade.price}
                  data-testid={`software-button-${upgrade.id}`}
                >
                  {getButtonText(upgrade)}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Stats & Skills */}
      <div>
        <h3 className="text-terminal-bright text-lg mb-4 border-b border-terminal-green pb-2" data-testid="skills-title">
          SKILLS
        </h3>
        <div className="space-y-3">
          {skills.map(([skillName, skill]) => (
            <div key={skillName} data-testid={`skill-${skillName}`}>
              <div className="flex justify-between text-sm mb-1">
                <span data-testid={`skill-name-${skillName}`}>
                  {skillName.charAt(0).toUpperCase() + skillName.slice(1).replace(/([A-Z])/g, ' $1')}
                </span>
                <span className={skill.locked ? "text-terminal-dim" : "text-terminal-bright"} data-testid={`skill-level-${skillName}`}>
                  {skill.locked ? 'LOCKED' : `Level ${skill.level}`}
                </span>
              </div>
              <div className="flex items-center">
                <div className={`flex-1 bg-black border h-2 mr-2 ${skill.locked ? 'border-terminal-dim' : 'border-terminal-green'}`}>
                  <div 
                    className={skill.locked ? 'bg-terminal-dim h-full' : 'progress-fill h-full'}
                    style={{ width: skill.locked ? '0%' : `${(skill.xp / skill.maxXp) * 100}%` }}
                    data-testid={`skill-progress-${skillName}`}
                  ></div>
                </div>
                <span className={`text-xs ${skill.locked ? 'text-terminal-dim' : ''}`} data-testid={`skill-xp-${skillName}`}>
                  {skill.locked ? 'LOCKED' : `${skill.xp}/${skill.maxXp} XP`}
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 border border-terminal-green p-3" data-testid="guild-status">
          <h4 className="text-terminal-bright font-bold mb-2" data-testid="guild-status-title">GUILD STATUS</h4>
          <div className="text-sm space-y-1">
            <div className="flex justify-between">
              <span>Rank:</span>
              <span className="text-terminal-bright" data-testid="guild-rank">{gameState.guildRank}</span>
            </div>
            <div className="flex justify-between">
              <span>Reputation:</span>
              <span className="text-terminal-bright" data-testid="guild-reputation">+{gameState.reputation}</span>
            </div>
            <div className="flex justify-between">
              <span>Jobs Completed:</span>
              <span className="text-terminal-bright" data-testid="guild-jobs">{gameState.jobsCompleted}</span>
            </div>
            <div className="flex justify-between">
              <span>Success Rate:</span>
              <span className="text-terminal-bright" data-testid="guild-success-rate">{gameState.successRate}%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
