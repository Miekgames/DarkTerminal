import { useState, useEffect } from 'react';
import { GameStateType, Mission } from '@/types/game';
import { useGameState } from '@/hooks/use-game-state';
import { useMobile } from '@/hooks/use-mobile';
import QuestTerminal from './quest-terminal';

interface MissionsProps {
  gameState: GameStateType;
}

interface Quest {
  id: string;
  title: string;
  description: string;
  objective: string;
  commands: string[];
  expectedOutputs: string[];
  reward: number;
  difficulty: string;
  skillRequired: number;
  repRequired: number;
}

interface Contract {
  id: string;
  title: string;
  description: string;
  objective: string;
  commands: string[];
  expectedOutputs: string[];
  reward: number;
  difficulty: string;
  estimatedTime: number;
  requiredSkills: string[];
  riskFactor: number;
}

export default function Missions({ gameState }: MissionsProps) {
  const [puzzleAnswer, setPuzzleAnswer] = useState(['', '', '', '']);
  const [timeLeft, setTimeLeft] = useState(154);
  const [activeQuest, setActiveQuest] = useState<Quest | null>(null);
  const [activeContract, setActiveContract] = useState<Quest | null>(null);
  const { missions, isLoading } = useGameState();
  const isMobile = useMobile();

  // Define available quests
  const availableQuests: Quest[] = [
    {
      id: "quest_001",
      title: "First Hack Tutorial",
      description: "Learn the basics of network infiltration and data extraction. This tutorial will guide you through your first successful hack.",
      objective: "Complete your first network scan and hack operation",
      commands: ["scan", "hack 192.168.1.15"],
      expectedOutputs: [
        "Network scan complete. Vulnerable targets found...",
        "Initiating hack on 192.168.1.15...\nRoot access gained! Files copied to /stolen_data/\nCredits earned: $150"
      ],
      reward: 150,
      difficulty: "Beginner",
      skillRequired: 20,
      repRequired: 5
    },
    {
      id: "quest_002", 
      title: "Data Theft Operation",
      description: "A corporate client needs sensitive data extracted from a competitor's database. Multiple steps required for success.",
      objective: "Extract corporate passwords and launder the proceeds",
      commands: ["stealth", "steal passwords", "launder"],
      expectedOutputs: [
        "Stealth mode activated. Digital footprint minimized.",
        "Cracking password hashes...\nExtracted 134 plaintext passwords\nCredits earned: $200",
        "Laundering money through offshore accounts...\nClean money received: $140"
      ],
      reward: 300,
      difficulty: "Intermediate",
      skillRequired: 35,
      repRequired: 25
    },
    {
      id: "quest_003",
      title: "Corporate Espionage",
      description: "High-value target requires advanced techniques. Extract trade secrets from a Fortune 500 company.",
      objective: "Infiltrate corporate network and steal valuable data",
      commands: ["proxy", "spoof location", "steal corporate"],
      expectedOutputs: [
        "Proxy chain established. Traffic routing through 7 countries.",
        "Location spoofed to: Moscow, Russia\nDigital fingerprints altered.",
        "Infiltrating corporate servers...\nDownloaded: Patent files, merger documents\nCredits earned: $2000"
      ],
      reward: 2500,
      difficulty: "Expert",
      skillRequired: 80,
      repRequired: 120
    }
  ];

  const canStartQuest = (quest: Quest) => {
    const currentSkill = gameState?.skills?.hacking || 25;
    const currentRep = gameState?.reputation || 10;
    return currentSkill >= quest.skillRequired && currentRep >= quest.repRequired;
  };

  const startQuest = (quest: Quest) => {
    if (canStartQuest(quest)) {
      setActiveQuest(quest);
    }
  };

  const completeQuest = () => {
    setActiveQuest(null);
  };

  const completeContract = () => {
    setActiveContract(null);
  };

  // Convert mission to quest format for terminal interface
  const convertMissionToQuest = (mission: Mission): Quest => {
    const commands = generateCommandsForMission(mission);
    const expectedOutputs = generateExpectedOutputs(mission, commands);
    
    return {
      id: mission.id,
      title: mission.title,
      description: mission.description,
      objective: `Complete ${mission.title} - ${mission.description}`,
      commands,
      expectedOutputs,
      reward: mission.reward,
      difficulty: mission.difficulty,
      skillRequired: mission.riskFactor, // Use risk factor as skill requirement
      repRequired: mission.riskFactor / 2 // Use half of risk factor as rep requirement
    };
  };

  const generateCommandsForMission = (mission: Mission): string[] => {
    const commands: string[] = [];
    
    // Add commands based on required skills and mission type
    if (mission.requiredSkills.includes('emailSpoofing')) {
      commands.push('scan email servers', 'spoof sender@techcorp.com', 'steal emails');
    }
    if (mission.requiredSkills.includes('passwordCracking')) {
      commands.push('crack passwords', 'decrypt files');
    }
    if (mission.requiredSkills.includes('gpsSpoofing')) {
      commands.push('locate target vehicle', 'spoof gps coordinates', 'redirect route');
    }
    if (mission.requiredSkills.includes('networkIntrusion')) {
      commands.push('scan network', 'exploit vulnerabilities', 'gain access');
    }
    if (mission.requiredSkills.includes('advancedHacking')) {
      commands.push('stealth mode', 'bypass firewalls', 'extract classified data');
    }
    if (mission.requiredSkills.includes('stealthMode')) {
      commands.push('enable stealth protocols', 'mask digital footprint');
    }

    // Add generic completion command
    commands.push('complete mission');
    
    return commands.length > 0 ? commands : ['scan target', 'exploit system', 'extract data', 'complete mission'];
  };

  const generateExpectedOutputs = (mission: Mission, commands: string[]): string[] => {
    return commands.map((command, index) => {
      if (command.includes('scan')) {
        return 'Target systems identified. Vulnerabilities detected...';
      }
      if (command.includes('spoof') || command.includes('crack') || command.includes('exploit')) {
        return `${command} executed successfully. Security bypassed...`;
      }
      if (command.includes('steal') || command.includes('extract')) {
        return `Data extraction complete. ${Math.floor(Math.random() * 500 + 100)} files retrieved...`;
      }
      if (command.includes('complete')) {
        return `Mission "${mission.title}" completed successfully!\nCredits earned: $${mission.reward.toLocaleString()}\nRisk assessment: ${mission.difficulty}`;
      }
      return `${command} - Operation successful. Proceeding to next phase...`;
    });
  };

  const canAcceptContract = (mission: Mission) => {
    const currentSkill = gameState?.skills?.hacking || 25;
    const currentRep = gameState?.reputation || 10;
    const requiredSkill = mission.riskFactor;
    const requiredRep = mission.riskFactor / 2;
    return currentSkill >= requiredSkill && currentRep >= requiredRep;
  };

  const acceptContract = (mission: Mission) => {
    if (canAcceptContract(mission)) {
      const questFormat = convertMissionToQuest(mission);
      setActiveContract(questFormat);
    }
  };

  useEffect(() => {
    if (gameState.activeMission) {
      const timer = setInterval(() => {
        setTimeLeft(prev => Math.max(0, prev - 1));
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [gameState.activeMission]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'LOW': return 'border-green-400 text-green-400';
      case 'MEDIUM': return 'border-terminal-warning text-terminal-warning';
      case 'HIGH': return 'border-terminal-error text-terminal-error';
      default: return 'border-terminal-green text-terminal-green';
    }
  };

  const handlePuzzleInputChange = (index: number, value: string) => {
    if (value.length <= 1) {
      const newAnswer = [...puzzleAnswer];
      newAnswer[index] = value.toUpperCase();
      setPuzzleAnswer(newAnswer);
    }
  };

  if (isLoading || !missions) {
    return (
      <div className="flex items-center justify-center h-full" data-testid="missions-loading">
        <div className="terminal-glow">LOADING MISSION DATA...</div>
      </div>
    );
  }

  return (
    <>
      <div className={`${isMobile ? 'space-y-4' : 'grid grid-cols-2 gap-6'}`} data-testid="missions-component">
        {/* Available Quests */}
        <div>
          <h3 className="text-terminal-bright text-lg mb-4 border-b border-terminal-green pb-2" data-testid="available-quests-title">
            INTERACTIVE QUESTS
          </h3>
          <div className="space-y-4">
            {availableQuests.map((quest) => (
              <div 
                key={quest.id} 
                className="border border-terminal-green p-4 transition-all hover:border-terminal-bright"
                data-testid={`quest-card-${quest.id}`}
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="text-terminal-bright font-bold" data-testid={`quest-title-${quest.id}`}>
                    {quest.title}
                  </h4>
                  <span className={`text-xs border px-2 py-1 ${getDifficultyColor(quest.difficulty === 'Beginner' ? 'LOW' : quest.difficulty === 'Intermediate' ? 'MEDIUM' : 'HIGH')}`} data-testid={`quest-difficulty-${quest.id}`}>
                    {quest.difficulty}
                  </span>
                </div>
                <p className="text-sm text-terminal-dim mb-3" data-testid={`quest-description-${quest.id}`}>
                  {quest.description}
                </p>
                <div className="text-xs text-terminal-warning mb-3">
                  Objective: {quest.objective}
                </div>
                <div className="flex justify-between items-center text-xs mb-3">
                  <span className="text-terminal-bright" data-testid={`quest-reward-${quest.id}`}>
                    REWARD: ${quest.reward.toLocaleString()}
                  </span>
                  <span className="text-terminal-dim">
                    Steps: {quest.commands.length}
                  </span>
                </div>
                <div className="text-xs text-terminal-dim mb-3">
                  Required: Hack {quest.skillRequired}+, Rep {quest.repRequired}+
                </div>
                {canStartQuest(quest) ? (
                  <button 
                    onClick={() => startQuest(quest)}
                    className="bg-terminal-green text-black px-3 py-1 text-xs font-bold hover:bg-terminal-bright transition-colors w-full"
                    data-testid={`start-quest-${quest.id}`}
                  >
                    START QUEST
                  </button>
                ) : (
                  <div className="text-terminal-error text-xs text-center py-1 border border-terminal-error">
                    INSUFFICIENT SKILLS/REPUTATION
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Available Missions */}
        <div>
          <h3 className="text-terminal-bright text-lg mb-4 border-b border-terminal-green pb-2" data-testid="available-missions-title">
            AVAILABLE CONTRACTS
          </h3>
          <div className="space-y-4">
            {missions.map((mission) => (
              <div 
                key={mission.id} 
                className="mission-card border border-terminal-green p-4 transition-all cursor-pointer"
                data-testid={`mission-card-${mission.id}`}
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="text-terminal-bright font-bold" data-testid={`mission-title-${mission.id}`}>
                    {mission.title}
                  </h4>
                  <span className={`text-xs border px-2 py-1 ${getDifficultyColor(mission.difficulty)}`} data-testid={`mission-difficulty-${mission.id}`}>
                    {mission.difficulty}
                  </span>
                </div>
                <p className="text-sm text-terminal-dim mb-3" data-testid={`mission-description-${mission.id}`}>
                  {mission.description}
                </p>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-terminal-bright" data-testid={`mission-reward-${mission.id}`}>
                    REWARD: ${mission.reward.toLocaleString()}
                  </span>
                  <span className="text-terminal-dim" data-testid={`mission-eta-${mission.id}`}>
                    ETA: {mission.estimatedTime} MIN
                  </span>
                </div>
                <div className="text-xs text-terminal-dim mb-3" data-testid={`mission-skills-${mission.id}`}>
                  Skills required: {mission.requiredSkills.join(', ')}
                </div>
                <div className="text-xs text-terminal-dim mb-3">
                  Required: Hack {mission.riskFactor}+, Rep {Math.floor(mission.riskFactor / 2)}+
                </div>
                {canAcceptContract(mission) ? (
                  <button 
                    onClick={() => acceptContract(mission)}
                    className="bg-terminal-green text-black px-3 py-1 text-xs font-bold hover:bg-terminal-bright transition-colors w-full"
                    data-testid={`accept-contract-${mission.id}`}
                  >
                    ACCEPT CONTRACT
                  </button>
                ) : (
                  <div className="text-terminal-error text-xs text-center py-1 border border-terminal-error">
                    INSUFFICIENT SKILLS/REPUTATION
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quest Terminal Modal */}
      {activeQuest && (
        <QuestTerminal 
          quest={activeQuest}
          onComplete={completeQuest}
          onClose={() => setActiveQuest(null)}
        />
      )}

      {/* Contract Terminal Modal */}
      {activeContract && (
        <QuestTerminal 
          quest={activeContract}
          onComplete={completeContract}
          onClose={() => setActiveContract(null)}
        />
      )}
    </>
  );
}