import { useState, useEffect } from 'react';
import { GameStateType, Mission } from '@/types/game';

const STORAGE_KEY = 'hacker-simulator-game-state';
const MISSIONS_KEY = 'hacker-simulator-missions';

export function useGameState() {
  const [gameState, setGameState] = useState<GameStateType | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [missions, setMissions] = useState<Mission[]>([]);

  const saveGameState = (state: GameStateType) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (error) {
      console.error('Failed to save game state:', error);
    }
  };

  const saveMissions = (missionsData: Mission[]) => {
    try {
      localStorage.setItem(MISSIONS_KEY, JSON.stringify(missionsData));
    } catch (error) {
      console.error('Failed to save missions:', error);
    }
  };

  const initializeDefaultState = () => {
    const defaultState: GameStateType = {
      id: crypto.randomUUID(),
      userId: 'anonymous_user_7331',
      credits: 50, // Start with very little money
      riskLevel: 'LOW',
      guildRank: 'INITIATE',
      reputation: 10, // Start with low reputation
      jobsCompleted: 0,
      successRate: 100,
      skills: {
        hacking: 25,
        stealth: 15,
        social: 10,
        hardware: 20
      },
      hardware: {
        processor: 'Intel Celeron',
        ram: '4GB',
        network: 'Ethernet',
        storage: '500GB HDD'
      },
      software: {
        os: 'Linux Terminal',
        proxy: 'Basic',
        encryption: 'AES-128',
        firewall: 'Disabled'
      },
      createdAt: new Date(),
      updatedAt: new Date(),
      activeMission: null
    };
    setGameState(defaultState);
    saveGameState(defaultState);
  };

  const initializeDefaultMissions = () => {
    const defaultMissions: Mission[] = [
      {
        id: 'mission-1',
        title: 'CORPORATE BREACH',
        description: 'Infiltrate TechCorp\'s email system and extract CEO communications. Client suspects insider trading.',
        difficulty: 'MEDIUM',
        reward: 3500,
        estimatedTime: 45,
        requiredSkills: ['emailSpoofing', 'passwordCracking'],
        riskFactor: 45,
        available: true,
        createdAt: new Date()
      },
      {
        id: 'mission-2',
        title: 'GPS MANIPULATION',
        description: 'Spoof delivery truck GPS to redirect packages. Anonymous client, crypto payment only.',
        difficulty: 'LOW',
        reward: 1200,
        estimatedTime: 20,
        requiredSkills: ['gpsSpoofing', 'networkIntrusion'],
        riskFactor: 25,
        available: true,
        createdAt: new Date()
      },
      {
        id: 'mission-3',
        title: 'GOVERNMENT DATABASE',
        description: 'Extract classified documents from defense contractor. HIGH RISK - AI monitoring active.',
        difficulty: 'HIGH',
        reward: 12000,
        estimatedTime: 120,
        requiredSkills: ['advancedHacking', 'stealthMode'],
        riskFactor: 85,
        available: true,
        createdAt: new Date()
      }
    ];
    setMissions(defaultMissions);
    saveMissions(defaultMissions);
  };

  useEffect(() => {
    // Load from localStorage on mount
    const savedState = localStorage.getItem(STORAGE_KEY);
    const savedMissions = localStorage.getItem(MISSIONS_KEY);
    
    if (savedState) {
      try {
        const parsed = JSON.parse(savedState);
        setGameState(parsed);
      } catch (error) {
        console.error('Failed to parse saved game state:', error);
        initializeDefaultState();
      }
    } else {
      initializeDefaultState();
    }

    if (savedMissions) {
      try {
        const parsedMissions = JSON.parse(savedMissions);
        setMissions(parsedMissions);
      } catch (error) {
        console.error('Failed to parse saved missions:', error);
        initializeDefaultMissions();
      }
    } else {
      initializeDefaultMissions();
    }
    
    setIsLoading(false);
  }, []);

  const updateGameState = (updates: Partial<GameStateType>) => {
    if (!gameState) return;
    
    const newState = { ...gameState, ...updates, updatedAt: new Date() };
    setGameState(newState);
    saveGameState(newState);
  };

  const addCredits = (amount: number) => {
    updateGameState({ credits: (gameState?.credits || 0) + amount });
  };

  const setRiskLevel = (level: string) => {
    updateGameState({ riskLevel: level });
  };

  const updateSkill = (skillName: string, amount: number) => {
    if (!gameState) return;
    updateGameState({
      skills: {
        ...gameState.skills,
        [skillName]: Math.min((gameState.skills as any)[skillName] + amount, 100)
      }
    });
  };

  const completeJob = () => {
    if (!gameState) return;
    
    const newJobsCompleted = gameState.jobsCompleted + 1;
    const newReputation = gameState.reputation + Math.floor(Math.random() * 50) + 25;
    
    updateGameState({
      jobsCompleted: newJobsCompleted,
      reputation: newReputation,
      activeMission: null
    });
  };

  const executeCommand = (command: string): { response: string; updateGameState: boolean; stateUpdates: any } => {
    let response = "";
    let updateGameState = false;
    let stateUpdates = {};
    const args = command.toLowerCase().split(' ');
    const cmd = args[0];
    const target = args[1] || '';
    
    switch (cmd) {
      case 'whoami':
        response = "anonymous_user_7331";
        break;
        
      case 'ls':
        response = `total 48
drwxr-xr-x  5 guest guild   4096 Oct 28 15:42 .
drwxr-xr-x  3 root  root    4096 Oct 15 10:30 ..
-rwx------  1 guest guild   1024 Oct 28 15:40 .blacknet_config
-rwxr-xr-x  1 guest guild   2048 Oct 28 15:35 mission_briefing.txt
-rwxr-xr-x  1 guest guild   8192 Oct 27 22:15 proxy_tools.bin
-rwx------  1 guest guild    512 Oct 28 14:20 secure_vault.enc
drwxr-xr-x  2 guest guild   4096 Oct 28 15:00 downloads
drwxr-xr-x  2 guest guild   4096 Oct 28 14:55 exploits
drwxr-xr-x  2 guest guild   4096 Oct 28 15:10 stolen_data`;
        break;
        
      case 'scan':
        const targets = [
          'INDIVIDUAL SYSTEMS:',
          '192.168.1.15 (TechCorp Server)',
          '192.168.1.23 (Ubuntu Linux)',
          '192.168.1.45 (IoT Smart Camera)',
          '192.168.1.67 (Router Admin)',
          '192.168.1.89 (MySQL Database)',
          '',
          'CORPORATE NETWORKS:',
          'techflow.com - TechFlow Industries (Financial)',
          'medicore.net - MediCore Healthcare',
          'cryptomax.org - CryptoMax Exchange',
          'edutech.edu - EduTech University',
          'neobank.com - NeoBank Services',
          'gameworld.io - GameWorld Entertainment',
          'retailgiant.com - RetailGiant Corp',
          'startupx.dev - StartupX Cloud'
        ];
        response = `Network scan complete. Vulnerable targets found:
${targets.join('\n')}
Exploit opportunities: SQL injection, weak passwords, unpatched systems`;
        updateGameState = true;
        stateUpdates = { riskLevel: "MEDIUM" };
        break;
        
      case 'hack':
        if (!target) {
          response = "Usage: hack [target_ip]\nExample: hack 192.168.1.15";
        } else {
          // Success depends on skills and reputation
          const currentSkills = gameState?.skills?.hacking || 25;
          const currentRep = gameState?.reputation || 10;
          const successChance = Math.min(0.9, (currentSkills + currentRep) / 150);
          const isSuccess = Math.random() < successChance;
          
          if (isSuccess) {
            const baseReward = Math.floor(Math.random() * 200) + 100; // $100-300
            const skillBonus = Math.floor(currentSkills / 10) * 10;
            const totalReward = baseReward + skillBonus;
            
            response = `Initiating hack on ${target}...
[████████████████████████████████████████] 100%
Root access gained! Extracting valuable data...
Files copied to /stolen_data/
Credits earned: $${totalReward}`;
            updateGameState = true;
            const currentCredits = gameState?.credits || 0;
            stateUpdates = { 
              riskLevel: "HIGH",
              credits: currentCredits + totalReward,
              reputation: (gameState?.reputation || 0) + 5
            };
          } else {
            response = `Initiating hack on ${target}...
[████████████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓] 35%
ERROR: Connection lost! Target detected intrusion.
Firewall activated. Trace initiated.
FAILED - No credits earned.`;
            updateGameState = true;
            stateUpdates = { 
              riskLevel: "HIGH",
              reputation: Math.max(0, (gameState?.reputation || 0) - 10)
            };
          }
        }
        break;
        
      case 'steal':
        if (!target) {
          response = `Usage: steal [data_type]
Available targets:
- credit_cards: Steal credit card numbers
- passwords: Extract password databases  
- crypto: Mine cryptocurrency wallets
- identity: Steal personal information
- corporate: Extract trade secrets`;
        } else {
          // Stealing requires high skills and reputation, with real failure risks
          const currentSkills = gameState?.skills?.hacking || 25;
          const currentRep = gameState?.reputation || 10;
          const currentStealth = gameState?.skills?.stealth || 15;
          
          const stealResults: {[key: string]: {
            reward: number;
            response: string;
            risk: string;
            successChance: number;
            skillRequired: number;
            repRequired: number;
          }} = {
            credit_cards: {
              reward: 800, // Reduced rewards
              response: `Breaching payment processor...
Found 12 active credit cards with CVV codes
Transferring to offshore accounts...
WARNING: High-value theft detected by AI monitors
Credits earned: $800`,
              risk: "HIGH",
              successChance: 0.3, // Very hard
              skillRequired: 60,
              repRequired: 80
            },
            passwords: {
              reward: 200,
              response: `Cracking password hashes...
Extracted 134 plaintext passwords
Uploading to darknet marketplace...
Credits earned: $200`,
              risk: "MEDIUM",
              successChance: 0.6,
              skillRequired: 30,
              repRequired: 25
            },
            crypto: {
              reward: 1200,
              response: `Scanning for cryptocurrency wallets...
Found Bitcoin wallet: 0.08 BTC
Transferring through mixing service...
Conversion complete. Credits earned: $1200`,
              risk: "HIGH",
              successChance: 0.25, // Very hard
              skillRequired: 70,
              repRequired: 100
            },
            identity: {
              reward: 400,
              response: `Harvesting personal data...
Social security numbers: 5
Addresses and phone numbers: 43
Creating fake identities for sale...
Credits earned: $400`,
              risk: "MEDIUM",
              successChance: 0.5,
              skillRequired: 40,
              repRequired: 30
            },
            corporate: {
              reward: 2000,
              response: `Infiltrating corporate servers...
Downloaded: Patent files, merger documents, client lists
Preparing anonymous sale to competitors...
Credits earned: $2000`,
              risk: "HIGH",
              successChance: 0.2, // Extremely hard
              skillRequired: 80,
              repRequired: 120
            }
          };
          
          const stealData = stealResults[target as keyof typeof stealResults];
          if (stealData) {
            // Check if player meets requirements
            if (currentSkills < stealData.skillRequired || currentRep < stealData.repRequired) {
              response = `ACCESS DENIED: Insufficient credentials for ${target} theft
Required: Hacking skill ${stealData.skillRequired}, Reputation ${stealData.repRequired}
Current: Hacking skill ${currentSkills}, Reputation ${currentRep}
Complete smaller jobs to build your skills and reputation.`;
            } else {
              // Calculate success based on skills, stealth, and random chance
              const skillFactor = (currentSkills + currentStealth) / 200;
              const finalSuccessChance = Math.min(0.8, stealData.successChance + skillFactor);
              const isSuccess = Math.random() < finalSuccessChance;
              
              if (isSuccess) {
                response = stealData.response;
                updateGameState = true;
                const currentCredits = gameState?.credits || 0;
                stateUpdates = { 
                  riskLevel: stealData.risk,
                  credits: currentCredits + stealData.reward,
                  reputation: (gameState?.reputation || 0) + Math.floor(stealData.reward / 100)
                };
              } else {
                response = `OPERATION FAILED: ${target} theft unsuccessful
Security detected intrusion attempt!
Countermeasures activated. Reputation damaged.
No credits earned. Try improving your skills first.`;
                updateGameState = true;
                stateUpdates = { 
                  riskLevel: "HIGH",
                  reputation: Math.max(0, (gameState?.reputation || 0) - 20)
                };
              }
            }
          } else {
            response = `Unknown target: ${target}. Type 'steal' for available options.`;
          }
        }
        break;
        
      case 'stealth':
        response = `Activating stealth protocols...
- Enabling TOR routing
- Spoofing MAC addresses  
- Clearing system logs
- Disabling location services
Digital footprint minimized. Risk level reduced.`;
        updateGameState = true;
        stateUpdates = { riskLevel: "LOW" };
        break;
        
      case 'proxy':
        response = `Establishing proxy chain...
Hop 1: Latvia (95.85.12.44)
Hop 2: Russia (178.154.23.67) 
Hop 3: North Korea (175.45.176.1)
Hop 4: Underground relay (HIDDEN)
Anonymous routing active.`;
        break;
        
      case 'upload':
        if (!target) {
          response = `Usage: upload [malware_type]
Available payloads:
- keylogger: Record keystrokes
- ransomware: Encrypt target files
- trojan: Remote access backdoor
- cryptominer: Mine cryptocurrency
- spyware: Monitor user activity`;
        } else {
          const payloads = {
            keylogger: "Keylogger deployed. Capturing passwords and messages...",
            ransomware: "Ransomware spreading through network. Files encrypting...",
            trojan: "Backdoor installed. Remote shell access established.",
            cryptominer: "Mining software deployed. Hijacking CPU cycles...",
            spyware: "Surveillance tools active. Recording webcam and microphone..."
          };
          
          response = payloads[target as keyof typeof payloads] || `Unknown payload: ${target}`;
          updateGameState = true;
          stateUpdates = { riskLevel: "HIGH" };
        }
        break;
        
      case 'decrypt':
        if (!target) {
          response = "Usage: decrypt [file]\nFound encrypted files: secure_vault.enc, passwords.hash, classified.gpg";
        } else {
          const currentSkills = gameState?.skills?.hacking || 25;
          const successChance = Math.min(0.7, currentSkills / 100);
          const isSuccess = Math.random() < successChance;
          
          if (isSuccess) {
            const reward = Math.floor(Math.random() * 150) + 50; // $50-200
            response = `Attempting to decrypt ${target}...
Trying dictionary attack...
Brute forcing encryption...
[████████████████████████████████████████] 100%
Decryption successful! Contents revealed.
Credits earned: $${reward}`;
            updateGameState = true;
            const currentCredits = gameState?.credits || 0;
            stateUpdates = { 
              riskLevel: "MEDIUM",
              credits: currentCredits + reward,
              reputation: (gameState?.reputation || 0) + 2
            };
          } else {
            response = `Attempting to decrypt ${target}...
Trying dictionary attack...
Brute forcing encryption...
[████████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓] 25%
DECRYPTION FAILED: File protection too strong
Your hacking skills need improvement.
Try easier targets first.`;
          }
        }
        break;
        
      case 'exploit':
        response = `Searching exploit database...
Available exploits for current targets:
- CVE-2023-4567: Buffer overflow in web server
- CVE-2023-8901: SQL injection vulnerability  
- CVE-2023-2134: Privilege escalation exploit
- Zero-day: Undisclosed browser exploit
Use: hack [target] to deploy exploits`;
        break;
        
      case 'launder':  // money laundering
        const currentCredits = gameState?.credits || 0;
        const minLaunder = 200; // Minimum amount to launder
        if (currentCredits < minLaunder) {
          response = `Insufficient dirty money. Need at least $${minLaunder} to launder.`;
        } else {
          const currentRep = gameState?.reputation || 0;
          const launderFee = currentRep > 50 ? 0.15 : 0.30; // Better reputation = lower fees
          const launderAmount = Math.floor(currentCredits * (1 - launderFee));
          response = `Laundering $${currentCredits} through offshore accounts...
Processing through shell companies...
Converting through cryptocurrency...
Clean money received: $${launderAmount}
Laundering fee (${Math.floor(launderFee * 100)}%): $${currentCredits - launderAmount}`;
          updateGameState = true;
          stateUpdates = { 
            riskLevel: "LOW",
            credits: launderAmount
          };
        }
        break;
        
      case 'trace':
        response = `Running counter-surveillance scan...
Checking for government monitoring...
Analyzing network traffic patterns...
Result: ${Math.random() > 0.7 ? 'AI HUNTER DETECTED - IMMEDIATE EVASION REQUIRED!' : 'No active traces found. You are secure.'}`;
        break;
        
      case 'darknet':
        response = `Connecting to darknet marketplace...
Available services:
- Stolen data marketplace
- Hacking tools and exploits
- Fake identity documents  
- Cryptocurrency mixing
- Anonymous communication
- Contract killer services (BLOCKED)
Use specific commands to access services.`;
        break;
        
      case 'spoof':
        if (!target) {
          response = "Usage: spoof [identity_type]\nOptions: email, phone, location, identity";
        } else {
          const spoofTypes = {
            email: "Email spoofing active. Sending as admin@techcorp.com",
            phone: "Phone number spoofed. Caller ID shows: FBI Cybercrime Division",
            location: "GPS coordinates spoofed. Showing location: Moscow, Russia",
            identity: "Digital identity masked. Profile shows: Mark Thompson, CPA"
          };
          response = spoofTypes[target as keyof typeof spoofTypes] || `Cannot spoof: ${target}`;
        }
        break;
        
      case 'social':
        response = `Social engineering database:
Target research completed on 347 individuals
- Facebook profiles scraped
- LinkedIn connections mapped
- Personal relationships identified
- Psychological profiles generated
Ready for targeted phishing attacks.`;
        break;
        
      case 'requests':
        response = `HACK REQUESTS SYSTEM ACCESSED
8 active job postings available in underground marketplace.
Clients range from revenge seekers to corporate espionage.
Rewards: $150 - $8000 depending on difficulty and risk.

Visit the HACK REQUESTS tab to view available jobs.
Each job has specific skill and reputation requirements.
Success rates vary based on difficulty level.

TIP: Start with Easy jobs to build reputation.`;
        break;
        
      case 'practice':
        // Easy practice jobs for beginners
        const practiceReward = Math.floor(Math.random() * 30) + 20; // $20-50
        response = `Running practice hack on test server...
Exploiting known vulnerability...
Practice completed successfully!
Credits earned: $${practiceReward}
Tip: Use 'scan' to find real targets for bigger rewards.`;
        updateGameState = true;
        const currentCreditsP = gameState?.credits || 0;
        stateUpdates = { 
          credits: currentCreditsP + practiceReward,
          skills: {
            ...gameState?.skills,
            hacking: Math.min(100, (gameState?.skills?.hacking || 25) + 1)
          }
        };
        break;
        
      case 'work':
        // Small legitimate programming jobs  
        const workReward = Math.floor(Math.random() * 50) + 30; // $30-80
        response = `Completing freelance programming job...
Fixed security vulnerability for small business.
Payment received through legitimate channels.
Credits earned: $${workReward}
This won't raise your risk level.`;
        updateGameState = true;
        const currentCreditsW = gameState?.credits || 0;
        stateUpdates = { 
          credits: currentCreditsW + workReward,
          skills: {
            ...gameState?.skills,
            hacking: Math.min(100, (gameState?.skills?.hacking || 25) + 1)
          }
        };
        break;
        
      case 'help':
        response = `BLACKNET COMMAND REFERENCE:
BASIC:
- whoami: Display current user
- ls: List files and directories  
- clear: Clear terminal output

BEGINNER EARNING:
- practice: Practice on test servers ($20-50, builds skills)
- work: Legitimate programming jobs ($30-80, safe)

RECONNAISSANCE: 
- scan: Scan network for vulnerabilities
- trace: Check for surveillance
- exploit: List available exploits

OFFENSIVE:
- hack [target]: Breach target system (requires skills)
- steal [data_type]: Steal specific data (high requirements)
- upload [malware]: Deploy malware
- decrypt [file]: Crack encryption

STEALTH & EVASION:
- stealth: Enable stealth mode
- proxy: Route through proxy chain
- spoof [type]: Spoof identity/location
- launder: Launder stolen money (30% fee)

ADVANCED:
- darknet: Access dark web services
- social: Social engineering tools
- requests: Check available hack requests

TIP: Start with 'practice' and 'work' to build skills and money!
Check the HACKING BOOK tab for complete command reference.
Visit HACK REQUESTS tab to take on client jobs.
WARNING: All criminal activities are monitored by AI hunters.`;
        break;
        
      case 'clear':
        response = "CLEAR_TERMINAL";
        break;
        
      default:
        response = `bash: ${command}: command not found
Type 'help' for available commands.`;
    }
    
    if (updateGameState && gameState) {
      const newState = { ...gameState, ...stateUpdates, updatedAt: new Date() };
      setGameState(newState);
      saveGameState(newState);
    }
    
    return { response, updateGameState, stateUpdates };
  };

  return {
    gameState,
    missions,
    isLoading,
    updateGameState,
    addCredits,
    setRiskLevel,
    updateSkill,
    completeJob,
    executeCommand
  };
}