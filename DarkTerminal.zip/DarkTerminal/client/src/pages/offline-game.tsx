import { useState, useEffect } from 'react';
import { useGameState } from '@/hooks/use-game-state';
import { useMobile } from '@/hooks/use-mobile';
import Terminal from '@/components/terminal/terminal';
import Desktop from '@/components/terminal/desktop';
import Missions from '@/components/terminal/missions';
import Darknet from '@/components/terminal/darknet';
import Network from '@/components/terminal/network';
import HackingBook from '@/components/terminal/hacking-book';
import HackRequests from '@/components/terminal/hack-requests';
import TutorialModal from '@/components/tutorial/tutorial-modal';

type Tab = 'terminal' | 'desktop' | 'missions' | 'darknet' | 'network' | 'book' | 'requests';

export default function OfflineGame() {
  const [activeTab, setActiveTab] = useState<Tab>('terminal');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showAlert, setShowAlert] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const { gameState, isLoading } = useGameState();
  const isMobile = useMobile();

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    // Check if user has completed tutorial
    const tutorialCompleted = localStorage.getItem('blacknet-tutorial-completed');
    if (!tutorialCompleted) {
      setShowTutorial(true);
    }
  }, []);

  useEffect(() => {
    // Random AI alert simulation
    const alertTimer = setTimeout(() => {
      setShowAlert(true);
      setTimeout(() => setShowAlert(false), 3000);
    }, Math.random() * 30000 + 15000);

    return () => clearTimeout(alertTimer);
  }, [showAlert]);

  if (isLoading || !gameState) {
    return (
      <div className="h-screen bg-black text-terminal-green font-mono flex flex-col items-center justify-center space-y-2">
        <div className="terminal-glow text-lg">INITIALIZING BLACKNET.EXE...</div>
        <div className="text-sm text-terminal-dim">
          <div>Establishing secure connection...</div>
          <div>Bypassing firewalls...</div>
          <div>Loading hacker tools...</div>
          <div className="animate-pulse">Connecting to guild network...</div>
        </div>
        <div className="flex space-x-1 mt-4">
          <div className="w-2 h-2 bg-terminal-green rounded-full animate-pulse"></div>
          <div className="w-2 h-2 bg-terminal-green rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
          <div className="w-2 h-2 bg-terminal-green rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></div>
        </div>
      </div>
    );
  }

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'LOW': return 'text-terminal-bright';
      case 'MEDIUM': return 'text-terminal-warning';
      case 'HIGH': return 'text-terminal-error';
      default: return 'text-terminal-green';
    }
  };

  return (
    <div className="bg-black text-terminal-green font-mono overflow-hidden">
      {/* CRT Scanlines Overlay */}
      <div className="crt-scanlines fixed inset-0 z-50 pointer-events-none"></div>

      {/* Main Terminal Interface */}
      <div className="h-screen flex flex-col">
        {/* Terminal Header */}
        <header className={`border-b border-terminal-green ${isMobile ? 'p-2' : 'p-2'} bg-black`} data-testid="header">
          <div className={`flex items-center ${isMobile ? 'flex-col space-y-2' : 'justify-between'}`}>
            <div className={`flex items-center ${isMobile ? 'justify-between w-full' : 'space-x-4'}`}>
              <div className="text-terminal-bright font-bold" data-testid="title">BLACKNET.EXE</div>
              {!isMobile && (
                <>
                  <div className="text-xs text-terminal-dim" data-testid="version">v2.4.7 - UNAUTHORIZED ACCESS</div>
                  <div className="text-xs text-terminal-warning" data-testid="offline-indicator">OFFLINE MODE</div>
                </>
              )}
              <button 
                onClick={() => setShowTutorial(true)}
                className="text-terminal-dim hover:text-terminal-green text-xs border border-terminal-dim hover:border-terminal-green px-2 py-1 transition-all"
                data-testid="help-button"
              >
                HELP
              </button>
            </div>
            <div className={`flex items-center ${isMobile ? 'justify-between w-full text-xs' : 'space-x-4 text-xs'}`}>
              <div className="text-terminal-warning" data-testid="risk-level">
                RISK: <span className={getRiskLevelColor(gameState.riskLevel)}>{gameState.riskLevel}</span>
              </div>
              <div data-testid="credits">$<span className="text-terminal-bright">{gameState.credits.toLocaleString()}</span></div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-terminal-green rounded-full animate-pulse" data-testid="status-indicator"></div>
                <div data-testid="online-status">SECURE</div>
              </div>
            </div>
          </div>
        </header>

        {/* Tab Navigation */}
        <nav className="border-b border-terminal-green bg-black" data-testid="tab-navigation">
          <div className={`flex ${isMobile ? 'justify-around' : ''}`}>
            {(['terminal', 'book', 'requests', 'desktop', 'missions', 'darknet', 'network'] as Tab[]).map((tab) => (
              <button
                key={tab}
                className={`${isMobile ? 'flex-1 px-1 py-2 text-xs' : 'px-4 py-2 text-sm'} border-r border-terminal-green hover:bg-opacity-20 hover:bg-terminal-green transition-all ${
                  activeTab === tab ? 'tab-active' : ''
                }`}
                onClick={() => setActiveTab(tab)}
                data-testid={`tab-${tab}`}
              >
                {isMobile ? 
                  (tab === 'book' ? 'BOOK' : 
                   tab === 'requests' ? 'JOBS' :
                   tab === 'darknet' ? 'DARK' :
                   tab.charAt(0).toUpperCase() + tab.slice(1, 4)) : 
                  (tab === 'book' ? 'HACKING BOOK' :
                   tab === 'requests' ? 'HACK REQUESTS' :
                   tab === 'darknet' ? 'DARKNET' :
                   tab.toUpperCase())
                }
              </button>
            ))}
          </div>
        </nav>

        {/* Main Content Area */}
        <main className={`flex-1 ${isMobile ? 'p-2' : 'p-4'} overflow-auto`} data-testid="main-content">
          {activeTab === 'terminal' && <Terminal gameState={gameState} />}
          {activeTab === 'book' && <HackingBook />}
          {activeTab === 'requests' && <HackRequests />}
          {activeTab === 'desktop' && <Desktop gameState={gameState} />}
          {activeTab === 'missions' && <Missions gameState={gameState} />}
          {activeTab === 'darknet' && <Darknet gameState={gameState} />}
          {activeTab === 'network' && <Network gameState={gameState} />}
        </main>

        {/* Status Bar */}
        <footer className="border-t border-terminal-green p-2 bg-black text-xs" data-testid="status-bar">
          <div className={`${isMobile ? 'flex flex-col space-y-1' : 'flex justify-between items-center'}`}>
            <div className={`${isMobile ? 'flex justify-between' : 'flex space-x-4'}`}>
              <span data-testid="system-status">{isMobile ? 'OPERATIONAL' : 'SYSTEM: OPERATIONAL'}</span>
              <span className="text-terminal-warning" data-testid="trace-detection">{isMobile ? 'TRACE: 12%' : 'TRACE DETECTION: 12%'}</span>
              {!isMobile && <span data-testid="guild-rank">GUILD RANK: {gameState.guildRank}</span>}
              <span className="text-terminal-bright" data-testid="offline-status">{isMobile ? 'SECURE' : 'OFFLINE - SECURE'}</span>
            </div>
            <div className={`${isMobile ? 'flex justify-center' : 'flex space-x-4'}`}>
              <span data-testid="current-time">{currentTime.toTimeString().split(' ')[0]}</span>
              {!isMobile && <span data-testid="timezone">LOCAL</span>}
            </div>
          </div>

          {/* Disclaimer */}
          <div className="border-t border-terminal-dim mt-2 pt-2 text-center">
            <div className="text-terminal-dim text-xs">
              ⚠️ DISCLAIMER: This is a fictional hacking simulation game for entertainment purposes only. 
              All companies, systems, and hacking activities are completely fake and educational. 
              Real hacking is illegal and harmful - this game does not promote or encourage illegal activities.
            </div>
          </div>
        </footer>
      </div>

      {/* Alert Popup */}
      {showAlert && (
        <div className="fixed top-4 right-4 bg-black border border-terminal-error p-4 text-terminal-error z-50" data-testid="alert-popup">
          <div className="glitch font-bold">⚠️ AI HUNTER DETECTED</div>
          <div className="text-sm mt-1">Initializing countermeasures...</div>
        </div>
      )}

      {/* Tutorial Modal */}
      <TutorialModal 
        isOpen={showTutorial} 
        onClose={() => setShowTutorial(false)} 
      />
    </div>
  );
}