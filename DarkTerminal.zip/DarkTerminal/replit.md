# Hacker Simulator Game

## Overview

This is a cyberpunk-themed hacker simulator game built as an offline web application. Players take on the role of a hacker navigating through various missions, upgrading skills and equipment, and managing their reputation in the underground hacking community. The game features a terminal-style interface with multiple tabs for different game aspects including missions, upgrades, network operations, and a desktop file system.

The game includes a comprehensive tutorial system that introduces new players to the mechanics through a series of briefing screens explaining each aspect of the interface and gameplay.

**Offline Design**: The game runs entirely in the browser using localStorage for persistence. No server or internet connection required - perfect for the story of a middle schooler with no internet access who discovered blacknet.exe on their laptop.

**Mobile Optimized**: The game automatically detects mobile devices and adapts the interface with responsive design, touch-friendly buttons, optimized font sizes, and mobile-specific layouts for the best experience on phones and tablets.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client is built using React with TypeScript as a pure offline application:

- **UI Framework**: React with TypeScript for type safety and component reusability
- **Styling**: Tailwind CSS with custom cyberpunk green terminal theme and shadcn/ui components for consistent design
- **State Management**: React hooks with localStorage for complete offline persistence
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized production builds

The application uses a tabbed interface design with separate components for different game sections (Terminal, Desktop, Missions, Upgrades, Network). All game data including state, missions, and command execution is handled client-side through custom hooks with localStorage persistence.

**Tutorial System**: A modal-based tutorial system guides new users through 7 comprehensive briefing screens covering all aspects of the game. The tutorial automatically appears for first-time users and can be accessed again via the HELP button in the header. Tutorial completion status is tracked in localStorage.

**Command System**: Terminal commands are processed entirely client-side with immediate responses and game state updates. The system includes 15+ authentic hacking commands including steal, decrypt, exploit, darknet access, and money laundering operations.

**Quest System**: Interactive terminal-based quest system that provides guided step-by-step hacking missions. Players must execute specific commands in sequence to complete objectives and earn rewards. The quest terminal opens in a full-screen modal with real-time command validation and progress tracking.

**Hacking Book**: Complete command reference system showing all available commands with detailed information about rewards, risks, skill requirements, and success rates. Organized by difficulty level from basic to advanced operations.

**Hack Requests**: Underground job marketplace where players can take on client missions ranging from simple revenge hacking ($150) to complex corporate espionage ($8000). Each job has specific skill and reputation requirements with realistic deadlines.

### Offline Architecture
The game operates as a pure client-side application with no backend dependencies:

- **Data Storage**: All game data stored in browser localStorage
- **State Management**: Custom React hooks manage game state, missions, and command execution
- **Command Processing**: Terminal commands processed entirely client-side with immediate responses
- **Mission System**: Pre-defined missions loaded from localStorage with progress tracking
- **Persistence**: Automatic saving of all game progress to localStorage

This design aligns perfectly with the game's narrative of a middle schooler discovering blacknet.exe on their offline laptop.

### Data Storage Solutions
The application uses a purely offline storage approach:

- **Local Storage**: Browser localStorage for all game data persistence including:
  - Player game state (credits, skills, equipment, reputation)
  - Mission data and progress tracking
  - Tutorial completion status
  - Terminal command history and responses
- **No Server Dependencies**: Completely offline operation with no external connections required
- **Data Persistence**: Automatic saving of all changes to localStorage for seamless session recovery

This approach ensures the game works perfectly offline and maintains the authentic feel of running mysterious software on an isolated laptop.

### User Experience
The game provides an authentic single-player hacker experience:

- **No Authentication**: Single-player offline experience with no login required
- **Persistent Progress**: All progress saved locally for continued play across sessions
- **Immersive Narrative**: Story-driven experience as an isolated middle schooler discovering underground hacking

The offline nature enhances the authenticity of the "discovered mysterious software" backstory.

## External Dependencies

### Core Technologies
- **Storage**: Browser localStorage for complete offline data persistence
- **UI Components**: Radix UI primitives with shadcn/ui for accessible components  
- **State Management**: Custom React hooks for game state and localStorage integration
- **Form Handling**: React Hook Form with Zod resolvers for validation
- **Offline Operation**: No external dependencies or network connections required

### Development Tools
- **Build System**: Vite with React plugin and TypeScript support
- **CSS Framework**: Tailwind CSS with PostCSS for styling
- **Code Quality**: TypeScript for type safety and better development experience
- **Development Environment**: Replit-specific plugins for cloud development

### Styling and Theming
- **Design System**: Custom terminal/cyberpunk theme with green color scheme
- **Typography**: Courier Prime font for authentic terminal feel
- **Component Library**: shadcn/ui components customized for the hacker aesthetic
- **Icons**: Lucide React for consistent iconography

The application can be deployed as a static site on any platform or run locally as a single HTML file, perfectly embodying the concept of mysterious hacker software that runs independently.