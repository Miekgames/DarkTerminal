import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const gameStates = pgTable("game_states", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  credits: integer("credits").default(1247),
  riskLevel: text("risk_level").default("LOW"),
  guildRank: text("guild_rank").default("INITIATE"),
  reputation: integer("reputation").default(0),
  jobsCompleted: integer("jobs_completed").default(0),
  successRate: integer("success_rate").default(100),
  skills: jsonb("skills").default({
    passwordCracking: { level: 1, xp: 0, maxXp: 200 },
    networkIntrusion: { level: 1, xp: 0, maxXp: 200 },
    socialEngineering: { level: 1, xp: 0, maxXp: 200 },
    virusDevelopment: { level: 0, xp: 0, maxXp: 300, locked: true }
  }),
  hardware: jsonb("hardware").default({
    quantumProcessor: false,
    stealthNetworkCard: true,
    neuralInterface: false
  }),
  software: jsonb("software").default({
    ghostProxy: false,
    aiPatternDisruptor: false,
    rootAccessToolkit: false
  }),
  activeMission: jsonb("active_mission"),
  completedMissions: jsonb("completed_missions").default([]),
  lastLogin: timestamp("last_login").default(sql`now()`),
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`)
});

export const missions = pgTable("missions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  difficulty: text("difficulty").notNull(), // LOW, MEDIUM, HIGH
  reward: integer("reward").notNull(),
  estimatedTime: integer("estimated_time"), // in minutes
  requiredSkills: jsonb("required_skills").default([]),
  riskFactor: integer("risk_factor").default(10), // 1-100
  available: boolean("available").default(true),
  createdAt: timestamp("created_at").default(sql`now()`)
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertGameStateSchema = createInsertSchema(gameStates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastLogin: true
});

export const insertMissionSchema = createInsertSchema(missions).omit({
  id: true,
  createdAt: true
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertGameState = z.infer<typeof insertGameStateSchema>;
export type GameState = typeof gameStates.$inferSelect;
export type InsertMission = z.infer<typeof insertMissionSchema>;
export type Mission = typeof missions.$inferSelect;
